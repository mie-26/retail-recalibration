"""Independent checks of cached-score selection, feedback support and final scores."""
from core import *
from analysis import effect
def main():
    lock=check_lock();checks={};E1=pd.read_parquet(OUT/'E1/daily.parquet');S=pd.read_csv(OUT/'E1/selection.csv');checked=0
    for c in configs():
        df=pd.read_csv(PRIOR/'replays'/c['case']/'daily.csv');got=E1[E1.case==c['case']]
        for row in S[(S.source==c['source'])&(S.H==c['horizon'])&(S.family==c['family'])].itertuples():
            block=c['outer_blocks'][row.block];a=got[(got.method==row.method+'_'+row.protocol)&(got.block==row.block)].sort_values(['origin','quantile']);b=df[(df.base_method==row.method)&(df.parameter==row.parameter)&df.origin.between(block['evaluation_first'],block['evaluation_last'])].sort_values(['origin','quantile'])
            np.testing.assert_array_equal(a[METRICS+['n']].to_numpy(),b[METRICS+['n']].to_numpy());checked+=1
    checks['E1_selected_daily_identity']=checked
    checks['E1_selection_records']=len(S)
    E2=pd.read_parquet(OUT/'E2/daily.parquet');choices=pd.read_csv(OUT/'E2/selection.csv');cv=pd.read_csv(OUT/'E2/validation_candidates.csv')
    for r in choices.itertuples():
        v=cv[(cv.source==r.source)&(cv.H==r.H)&(cv.family==r.family)&(cv.method==r.method)&(cv.block==r.block)&(cv['quantile']==r.quantile)]
        scores=dict(zip(v.parameter,v.loss));assert choose(scores,r.default)==r.parameter
        assert (v.last_maturity<=v.selection_origin).all()
    checks['E2_historical_selection_records']=len(choices)
    from calibration import daily_scores
    replay_checked=0;feedback_count=0
    for c in configs():
        z=case_input(c);got=E2[E2.case==c['case']];p=OUT/'E2/candidates'/c['case'];mask=z['origins']>=c['outer_blocks'][0]['evaluation_first'];ii=np.flatnonzero(mask)
        cc=choices[(choices.source==c['source'])&(choices.H==c['horizon'])&(choices.family==c['family'])]
        for method in cc.method.unique():
            q=ordered(z['base'].astype(float))
            for row in cc[cc.method==method].itertuples():
                block=c['outer_blocks'][row.block];take=(z['origins']>=block['evaluation_first'])&(z['origins']<=block['evaluation_last']);k=0 if row.quantile==.9 else 1
                q[take,:,k]=np.load(p/f'{method}_p{row.parameter:g}.npy',mmap_mode='r')[take,:,k]
            for sort in [False,True]:
                qq=np.sort(q,axis=-1) if sort else q;name=method+('_sorted' if sort else '');ss=daily_scores(z['truth'][mask],qq[mask],z['scale']);a=got[got.method==name].sort_values(['origin','quantile'])
                for metric in METRICS:np.testing.assert_allclose(a[metric].to_numpy(),ss[metric].ravel(),rtol=0,atol=1e-12,equal_nan=True)
                replay_checked+=1
            uns=got[got.method==method].groupby('origin').scaled_pinball.sum();srt=got[got.method==method+'_sorted'].groupby('origin').scaled_pinball.sum();assert (srt-uns<=1e-12).all()
        f=pd.read_parquet(p/'feedback.parquet');assert (f.latest_maturity<=f.origin).all();feedback_count+=len(f)
    checks['E2_selected_and_sorted_score_recomputations']=replay_checked;checks['E2_feedback_trace_rows']=feedback_count
    E3=pd.read_parquet(OUT/'E3/daily.parquet');replayed=0;fallback=0
    for c in configs():
        p=OUT/'E3/cases'/c['case'];z=case_input(c);pred=load(p/'predictions.npz');idx=np.searchsorted(z['origins'],pred['origins']);df=E3[E3.case==c['case']];s=spec(c)
        for method in ['Raw','old_reference','new_reference']:
            ss=daily_scores(z['truth'][idx],pred[method],z['scale']);a=df[df.method==method].sort_values(['origin','quantile'])
            for metric in METRICS:np.testing.assert_allclose(a[metric].to_numpy(),ss[metric].ravel(),rtol=0,atol=1e-12,equal_nan=True)
            replayed+=1
        for cut in range(s['eval_start'],s['eval_end']+1,c['update_interval']):
            take=(pred['origins']>=cut)&(pred['origins']<cut+c['horizon'])
            for method in ['old_reference','new_reference']:np.testing.assert_array_equal(pred[method][take],pred['Raw'][take]);fallback+=1
        f=pd.read_parquet(p/'feedback.parquet');assert (f.latest_maturity<=f.origin).all()
        for origin,g in f.groupby('origin'):assert g.eligible_origins.nunique()==1 and g.valid_residual_targets.nunique()==1
    checks['E3_score_recomputations']=replayed;checks['E3_event_arm_fallback_checks']=fallback
    pairs=pd.read_csv(OUT/'E3/pairs.csv');assert len(pairs)==564;checks['E3_pair_count']=len(pairs)
    for kind in ['E1','E2','E3']:
        d=pd.read_parquet(OUT/kind/'daily.parquet');q=pd.read_csv(OUT/'tables'/f'{kind}_quantile_scores.csv')
        for row in q.itertuples():
            g=d[(d.source==row.source)&(d.H==row.H)&(d.U==row.U)&(d.family==row.family)&(d.method==row.method)&(d['quantile']==row.quantile)]
            for metric in METRICS:np.testing.assert_allclose(getattr(row,metric),np.nansum(g[metric]*g.n)/g.n.sum(),atol=1e-12,rtol=0)
        checks[kind+'_summary_rows_recomputed']=len(q)
    checks['frozen_code_unchanged']=True
    write(OUT/'verification.json',dict(created=now(),status='PASS',freeze_sha256=lock,checks=checks,limitations='Confirms saved-score selection and arithmetic, not a fresh refit of the historical model bank.'))
    print(json.dumps(checks,indent=2),flush=True)
if __name__=='__main__':main()
