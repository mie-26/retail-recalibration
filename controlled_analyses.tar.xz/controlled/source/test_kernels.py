from core import *
from experiments import pair_predictions
import unittest
def fixture(T=25,N=6):
    rng=np.random.default_rng(9);y=rng.poisson(4,(T,N)).astype(float)
    if N>1:y[3,1]=np.nan
    return dict(truth=y,base=np.tile(np.array([3.,6.]),(T,N,1)),scale=np.ones(N),groups=np.arange(N)%2,origins=np.arange(100,100+T),versions=np.where(np.arange(T)<12,90,112))
class Kernels(unittest.TestCase):
    def test_future_label_invariance(self):
        z=fixture();other={k:v.copy() for k,v in z.items()};other['truth'][13:]=900
        for r in ['WQ','QT']:
          for l in ['series','group','global']:
            p=8 if r=='WQ' else .1;a,_,_=replay_control(z,3,r,l,p);b,_,_=replay_control(other,3,r,l,p)
            np.testing.assert_array_equal(a[:16],b[:16])
    def test_exact_maturity_and_single_consumption(self):
        z=fixture(8,2);z['truth'][:]=100.;q,_,_=replay_control(z,2,'QT','global',.1)
        np.testing.assert_array_equal(q[:2],z['base'][:2]);np.testing.assert_allclose(q[2],z['base'][2]+.1*TAUS);np.testing.assert_allclose(q[3],z['base'][3]+.2*TAUS)
    def test_replication_does_not_multiply_steps(self):
        z=fixture();zz={k:(np.repeat(v,3,axis=1) if k in ['base','truth'] else np.repeat(v,3) if k in ['scale','groups'] else v.copy()) for k,v in z.items()}
        for r in ['QT','WQ']:
          for l in ['group','global']:
            p=.1 if r=='QT' else 8;a,_,_=replay_control(z,2,r,l,p);b,_,_=replay_control(zz,2,r,l,p);np.testing.assert_allclose(np.repeat(a,3,axis=1),b,atol=1e-12)
    def test_empty_feedback_fallback(self):
        z=fixture();z['truth'][:]=np.nan
        for r in ['WQ','QT']:
          for l in ['series','group','global']:
            q,logs,_=replay_control(z,2,r,l,8 if r=='WQ' else .1);np.testing.assert_array_equal(q,ordered(z['base']));assert all(a['fallback_all'] for a in logs)
    def test_missing_is_not_zero(self):
        z=fixture(8,2);z['truth'][:]=np.nan;z['truth'][0,0]=100
        q,_,_=replay_control(z,2,'QT','global',.1);np.testing.assert_allclose(q[2],z['base'][2]+TAUS*.1)
    def test_weighted_inverse(self):
        self.assertEqual(weighted_inverse(np.array([0.,10.,20.]),np.array([.5,.5,1.]),.5),10.)
        self.assertEqual(weighted_inverse(np.array([np.nan]),np.array([1.]),.9),0.)
    def test_single_series_inverse_convention(self):
        z=fixture(6,1);z['truth'][:,0]=np.arange(6.);z['base'][:]=0
        q,_,_=replay_control(z,1,'WQ','series',4)
        self.assertEqual(q[4,0,0],3.)
    def test_group_isolation(self):
        z=fixture();zz={k:v.copy() for k,v in z.items()};zz['truth'][:,z['groups']==1]=1000
        for r in ['WQ','QT']:
            p=8 if r=='WQ' else .1;a,_,_=replay_control(z,2,r,'group',p);b,_,_=replay_control(zz,2,r,'group',p);np.testing.assert_array_equal(a[:,z['groups']==0],b[:,z['groups']==0])
    def test_pair_equal_references(self):
        z=fixture();qs,logs=pair_predictions(z['truth'],z['base'],z['base'],z['scale'],z['groups'],z['origins'],3,8);np.testing.assert_array_equal(qs[0],qs[1]);np.testing.assert_array_equal(qs[0][:3],ordered(z['base'][:3]));assert all(r['latest_maturity']<=r['origin'] for r in logs)
    def test_pair_causality(self):
        z=fixture();other=z['truth'].copy();other[13:]=1000
        a,_=pair_predictions(z['truth'],z['base']*2,z['base'],z['scale'],z['groups'],z['origins'],3,8);b,_=pair_predictions(other,z['base']*2,z['base'],z['scale'],z['groups'],z['origins'],3,8)
        for x,y in zip(a,b):np.testing.assert_array_equal(x[:16],y[:16])
    def test_tie_breaking(self):
        self.assertEqual(choose({28:1.,56:1.,112:1.},56),56);self.assertEqual(choose({28:1.,56:2.,112:1.},56),28)
    def test_shared_selection_boundary(self):
        for c in configs():
            for b in c['outer_blocks']:assert b['validation_last']+c['horizon']<=b['selection_origin'] and b['validation_last']<b['evaluation_first']
    def test_feature_future_invariance(self):
        # The frozen feature builder is exercised without fitting any model.
        from models import Design
        d=Design('retail',7);y=d.y.copy();d.y=y;o=500;x=d.make(np.array([o]));d.y[:,o:]=123456
        np.testing.assert_array_equal(x,d.make(np.array([o])))
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Kernels));write(OUT/'tests.json',dict(created=now(),tests_run=result.testsRun,failed=len(result.failures)+len(result.errors),details=[str(x) for x in result.failures+result.errors]));sys.exit(0 if result.wasSuccessful() else 1)
