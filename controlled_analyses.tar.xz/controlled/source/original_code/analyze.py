"""Aggregate prespecified paired effects. Never treat seeds/stores as enterprises."""
from common import *
from functools import lru_cache
FIELDS=['source','H','U','family','history','phase','chain_delay','mode']
METRICS=['scaled_pinball','pinball','weak','strict','equality','zero_tie']
@lru_cache(None)
def boot_index(T,L):
    rng=np.random.default_rng(20261021);starts=rng.integers(0,T,(3000,(T+L-1)//L));return ((starts[:,:,None]+np.arange(L))%T).reshape(3000,-1)[:,:T]
@lru_cache(None)
def boot_weights(T,L):
    # Identical circular-block draws, represented as frequency weights to avoid
    # a large draws-by-time-by-metric temporary array for each contrast.
    ix=boot_index(T,L);w=np.zeros((len(ix),T),dtype=float)
    for i,row in enumerate(ix):w[i]=np.bincount(row,minlength=T)
    return w
def vector(df):
    df=df.groupby(['origin','quantile'],as_index=False)[['n']+METRICS].mean().sort_values(['origin','quantile'])
    o=np.sort(df.origin.unique());assert len(df)==len(o)*2
    n=df.n.to_numpy().reshape(-1,2);np.testing.assert_array_equal(n[:,0],n[:,1]);n=n[:,0]
    arrays={k:df[k].to_numpy().reshape(-1,2) for k in METRICS}
    names=['joint_scaled','q90_scaled','q95_scaled','joint_units','q90_weak','q95_weak','q90_strict','q95_strict','q90_equality','q95_equality','q90_zero_tie','q95_zero_tie']
    v=np.column_stack([arrays['scaled_pinball'].mean(1),arrays['scaled_pinball'],arrays['pinball'].mean(1),arrays['weak'],arrays['strict'],arrays['equality'],arrays['zero_tie']])
    return o,n,v,names
def contrast(a,b,meta,H,unit):
    o,n,av,names=vector(a);ob,nb,bv,_=vector(b);np.testing.assert_array_equal(o,ob);np.testing.assert_array_equal(n,nb)
    ok=n>0;assert ok.any();an=np.nan_to_num(av)*n[:,None];bn=np.nan_to_num(bv)*n[:,None]
    am=an.sum(0)/n.sum();bm=bn.sum(0)/n.sum();diff=am-bm
    point=dict(**meta,n_origins=len(o),n_pairs=float(n.sum()),candidate_joint=am[0],reference_joint=bm[0],relative_loss_pct=100*(am[0]/bm[0]-1),absolute_loss=diff[0],**{name+'_difference':float(diff[i]*(100 if i>=4 else 1)) for i,name in enumerate(names)})
    rows=[]
    for L in sorted(set([H,2*H,4*H,56 if unit=='day' else 8])):
        if len(o)<4*L:continue
        weights=boot_weights(len(o),L);den=weights@n;aa=(weights@an)/den[:,None];bb=(weights@bn)/den[:,None]
        vals={'relative_loss_pct':100*(aa[:,0]/bb[:,0]-1),'absolute_loss':aa[:,0]-bb[:,0]}
        vals.update({name+'_difference':(aa[:,i]-bb[:,i])*(100 if i>=4 else 1) for i,name in enumerate(names)})
        for metric,v in vals.items():
            lo,hi=np.quantile(v,[.025,.975]);rows.append(dict(**meta,metric=metric,block_length=L,reference_block=L==2*H,n_origins=len(o),draws=3000,point=point[metric],lower=float(lo),upper=float(hi)))
    return point,rows

def main(partial=False):
    check_lock();summ=[];daily=[];feedback=[];costs=[];strata=[];case_rows=[]
    for path in sorted((OUT/'replays').glob('*/*/complete.json')):
        m=read(path);p=path.parent;meta={k:m[k] for k in FIELDS+['seed','case']};case_rows.append(meta)
        for f,bag in [('scores.csv',summ),('daily.csv',daily),('feedback.csv',feedback),('costs.csv',costs),('strata.csv',strata)]:
            if (p/f).exists():
                z=pd.read_csv(p/f);z=z.assign(**meta);bag.append(z)
    counts=pd.DataFrame(case_rows).groupby('mode').size().to_dict()
    if not partial:
        assert counts=={'bridge':36,'core':108,'history':24,'mechanism':36,'phase':48},counts
        idcols=['source','H','U','family','seed','history','phase','chain_delay','mode'];expected=set()
        for source in ['m5','retail','dominicks','m5_weekly']:
            spec=read(OUT/'panels'/source/'spec.json')
            for H in spec['Hs']:
                for U in spec['Us']:
                    for family in ['lgbm','mlp']:
                        for seed in SEEDS:
                            expected.add((source,H,U,family,seed,spec['history'],0,0,'bridge' if source=='m5_weekly' else 'core'))
                            if source!='m5_weekly' and seed==SEEDS[0]:expected.add((source,H,U,family,seed,spec['history'],0,0,'mechanism'))
                            if source in ['m5','retail'] and U in [28,56]:expected.add((source,H,U,family,seed,spec['history'],14,0,'phase'))
                            if source=='m5' and U==28:
                                for hist in [42,84]:expected.add((source,H,U,family,seed,hist,0,0,'history'))
        actual={tuple(row[k] for k in idcols) for row in case_rows};assert actual==expected,dict(missing=list(expected-actual),unexpected=list(actual-expected))
    table=OUT/'tables';table.mkdir(exist_ok=True)
    S=pd.concat(summ,ignore_index=True);D=pd.concat(daily,ignore_index=True);F=pd.concat(feedback,ignore_index=True);C=pd.concat(costs,ignore_index=True);G=pd.concat(strata,ignore_index=True)
    csv(table/'all_quantile_scores.csv',S);csv(table/'all_daily_scores.csv',D);csv(table/'strata_scores.csv',G);csv(table/'replay_costs.csv',C)
    keys=FIELDS+['method','delay','window_kind','window']
    A=S.groupby(keys,dropna=False).agg(joint_scaled=('scaled_pinball','mean'),joint_units=('pinball','mean'),n_seeds=('seed','nunique')).reset_index();csv(table/'joint_mean_scores.csv',A)
    # Full pooled per-q seed-average scores; bracket deficit captures overcoverage as well.
    Q=S.groupby(keys+['quantile'],as_index=False)[METRICS+['n']].mean();Q['bracket_distance']=np.maximum(Q['strict']-Q['quantile'],0)+np.maximum(Q['quantile']-Q.weak,0);csv(table/'quantile_mean_scores.csv',Q)
    avail=F.groupby(keys,as_index=False).agg(fallback_fraction=('fallback_all','mean'),mean_eligible_origins=('eligible_origins','mean'),mean_valid_residual_targets=('valid_residual_targets','mean'),mean_old_origins=('old_origins','mean'),active_series=('active_series','mean'))
    avail['ideal_isolate_active_fraction']=np.maximum(avail.U-avail.H-avail.delay,0)/avail.U;csv(table/'feedback_availability.csv',avail)
    points=[];intervals=[]
    for key,g in D.groupby(FIELDS,sort=True):
        meta=dict(zip(FIELDS,key));unit=read(OUT/'panels'/meta['source']/'spec.json')['unit'];H=meta['H']
        for (delay,kind,w),part in g.groupby(['delay','window_kind','window']):
            meta2=dict(**meta,delay=delay,window_kind=kind,window=w)
            pairs=[('R2_reuse','R0_raw'),('R3_isolate','R2_reuse')]
            if meta['mode']!='mechanism':pairs += [('R4_half','R2_reuse'),('R5_multiqt_nonnegative','R2_reuse'),('R1_global','R2_reuse')]
            for ca,ref in pairs:
                a=part[part.method==ca];b=part[part.method==ref]
                r,rr=contrast(a,b,dict(**meta2,candidate=ca,reference=ref,comparison='strategy'),H,unit);points.append(r);intervals+=rr
            if delay:
                for method in ['R2_reuse','R3_isolate']:
                    a=part[part.method==method];b=g[(g.delay==0)&(g.window_kind==kind)&(g.method==method)]
                    r,rr=contrast(a,b,dict(**meta2,candidate=method,reference=method+'_d0',comparison='delay'),H,unit);points.append(r);intervals+=rr
    # Prespecified phase comparison uses same target calendar and same seeds.
    for key,g in D[D['mode']=='phase'].groupby(['source','H','U','family']):
        meta=dict(zip(['source','H','U','family'],key));b=D[(D['mode']=='core')&(D.source==meta['source'])&(D.H==meta['H'])&(D.U==meta['U'])&(D.family==meta['family'])]
        for method in ['R0_raw','R2_reuse','R3_isolate']:
            r,rr=contrast(g[g.method==method],b[b.method==method],dict(**meta,mode='phase',candidate=method+'_phase14',reference=method+'_phase0',comparison='phase'),meta['H'],'day');points.append(r);intervals+=rr
    csv(table/'paired_effects.csv',points);csv(table/'paired_intervals.csv',intervals)
    # Three time thirds, still descriptive and overlapping target labels accounted in global time intervals.
    thirds=[]
    for key,g in D.groupby(FIELDS+['seed','method','delay','window_kind','window']):
        meta=dict(zip(FIELDS+['seed','method','delay','window_kind','window'],key));o=np.sort(g.origin.unique())
        for label,oo in zip(['early','middle','late'],np.array_split(o,3)):
            h=g[g.origin.isin(oo)]
            for tau,j in h.groupby('quantile'):
                den=j.n.sum();thirds.append(dict(**meta,period=label,quantile=tau,**{k:float(np.nansum(j[k]*j.n)/den) for k in METRICS}))
    csv(table/'time_thirds.csv',thirds)
    fits=[]
    for p in (OUT/'banks').glob('*/*/*/complete.json'):
        m=read(p);fits.append({k:m[k] for k in ['source','H','family','seed','history','cutoff','fit_seconds','inference_seconds','total_seconds','logical_quantile_models']}|m['training'])
    csv(table/'actual_fit_ledger.csv',fits);csv(table/'case_inventory.csv',case_rows)
    write(OUT/'analysis_complete.json',dict(created=now(),case_counts=counts,score_trajectories=len(S)//2,actual_fit_executions=sum(x['logical_quantile_models'] for x in fits),bank_fit_jobs=len(fits),fit_seconds=sum(x['fit_seconds'] for x in fits),replay_seconds=float(C.replay_seconds.sum()),paired_effects=len(points),interval_rows=len(intervals),partial=partial))
    print(read(OUT/'analysis_complete.json'),flush=True)
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');main(ap.parse_args().partial)
