"""Controlled calibration kernels; no model fitting or future-target access."""
from pathlib import Path
import os,sys,json,hashlib,time,warnings
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
BASE=ROOT/'outputs/sr_enhanced_20261021'
PRIOR=ROOT/'outputs/sr_strengthening_20261025'
OUT=ROOT/'outputs/sr_fairness_20261028'
PROPOSED=ROOT/'outputs/sr_fairness_plan_20261028/proposed_protocol.json'
sys.path.insert(0,str(ROOT/'work/sr_enhanced'))
from calibration import replay as legacy_replay, ordered, daily_scores
TAUS=np.array([.9,.95]);METRICS=['scaled_pinball','pinball','weak','strict','equality','zero_tie']
SEEDS=[20261021,20261022,20261023]
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=lambda v:v.item() if isinstance(v,np.generic) else str(v)),encoding='utf8');temp.replace(p)
def now():
    from datetime import datetime,timezone
    return datetime.now(timezone.utc).isoformat()
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def configs():return read(PROPOSED)['configurations']
def spec(c):return read(BASE/'panels'/c['source']/'spec.json')
def case_input(c):return load(BASE/'replays/core'/c['case']/'input.npz')
def meta(c):return dict(source=c['source'],H=c['horizon'],U=c['update_interval'],family=c['family'],seed=c['seed'],case=c['case'])
def save_csv(p,rows):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);pd.DataFrame(rows).to_csv(p,index=False,encoding='utf-8-sig')
def check_lock():
    f=read(OUT/'freeze_manifest.json');assert f['status']=='FROZEN'
    for p,h in f['code_sha256'].items():assert sha(ROOT/p)==h,('changed code',p)
    assert sha(PROPOSED)==f['proposed_sha256']
    return sha(OUT/'freeze_manifest.json')
def scoring(z,q,method,c,mask=None):
    if mask is None:mask=np.ones(len(q),dtype=bool)
    ids=np.flatnonzero(mask);ss=daily_scores(z['truth'][ids],q[ids],z['scale'])
    rows=[]
    for j,t in enumerate(ids):
        valid=np.isfinite(z['truth'][t]);cross=float((q[t,valid,0]>q[t,valid,1]).mean()) if valid.any() else np.nan
        for k,tau in enumerate(TAUS):rows.append(dict(**meta(c),method=method,origin=int(z['origins'][t]),quantile=tau,n=int(ss['n'][j]),crossing=cross,**{m:float(ss[m][j,k]) for m in METRICS}))
    return pd.DataFrame(rows)
def strata(z,q,method,c,mask):
    cohort=pd.read_csv(BASE/'panels'/c['source']/'cohort.csv');rows=[]
    for field in ['store_id','cat_id','group']:
        for val in cohort[field].unique():
            take=cohort[field].to_numpy()==val;ss=daily_scores(z['truth'][mask][:,take],q[mask][:,take],z['scale'][take]);den=ss['n'].sum()
            for k,tau in enumerate(TAUS):rows.append(dict(**meta(c),method=method,field=field,stratum=str(val),quantile=tau,n=int(den),**{m:float(np.nansum(ss[m][:,k]*ss['n'])/den) if den else np.nan for m in METRICS}))
    return rows
def labels_for(groups,sharing):
    if sharing=='series':return np.arange(len(groups))
    if sharing=='global':return np.zeros(len(groups),int)
    if sharing=='group':return np.unique(groups,return_inverse=True)[1]
    raise ValueError(sharing)
def weighted_inverse(v,w,tau):
    ok=np.isfinite(v)&(w>0);v=v[ok];w=w[ok]
    if not len(v):return 0.
    ix=np.argsort(v,kind='stable');v=v[ix];w=w[ix]
    return float(v[min(len(v)-1,np.searchsorted(np.cumsum(w),tau*w.sum(),side='left'))])
def replay_control(z,H,rule,sharing,param):
    """Calendar-window WQ or constant-step QT; equal mass per mature date."""
    start=time.perf_counter();b=ordered(z['base'].astype(float));y=z['truth'];sc=z['scale'];oo=z['origins'];vv=z['versions']
    T,N,K=b.shape;q=np.empty_like(b);labels=labels_for(z['groups'],sharing);G=int(labels.max())+1
    theta=np.zeros((G,K));res=(y[:,:,None]-b)/sc[None,:,None];logs=[]
    gm=[np.flatnonzero(labels==g) for g in range(G)] if sharing!='series' else None
    seen=np.zeros(N,bool);released_count=0;released_dates=0;last_consumed=-1
    for t,o in enumerate(oo):
        # Right inclusive mature boundary; processing occurs before current issue.
        mature=np.flatnonzero(oo+H<=o)
        if rule=='QT':
            for s in mature[mature>last_consumed]:
                valid=np.isfinite(y[s]);seen|=valid;released_count+=int(valid.sum());released_dates+=1
                feedback=TAUS-(y[s,:,None]<=q[s])
                if sharing=='series':theta[valid]+=float(param)*feedback[valid]
                else:
                    count=np.bincount(labels[valid],minlength=G)
                    for k in range(2):
                        total=np.bincount(labels[valid],weights=feedback[valid,k],minlength=G)
                        theta[:,k]+=float(param)*np.divide(total,count,out=np.zeros(G),where=count>0)
                last_consumed=int(s)
            q[t]=np.maximum(b[t]+theta[labels]*sc[:,None],0)
            ix=mature;active=int(seen.sum()) if sharing=='series' else sum(int((labels==g).sum()) for g in range(G) if seen[labels==g].any())
            nr=released_count
        else:
            assert rule=='WQ';ix=mature[oo[mature]>=o-int(param)]
            offset=np.zeros((N,2));valid=np.isfinite(y[ix]);nr=int(valid.sum());active=0
            if len(ix):
                if sharing=='series':
                    count=valid.sum(0);active=int((count>0).sum());a=np.sort(np.where(np.isfinite(res[ix]),res[ix],np.inf),axis=0)
                    for k,tau in enumerate(TAUS):
                        pos=np.maximum(0,np.ceil(tau*count).astype(int)-1)
                        offset[:,k]=np.where(count>0,a[pos,np.arange(N),k],0)
                else:
                    for members in gm:
                        rr=res[ix][:,members];count=np.isfinite(rr[:,:,0]).sum(1)
                        w=np.broadcast_to(np.divide(1.,count,out=np.zeros(len(ix)),where=count>0)[:,None],rr.shape[:2]).ravel()
                        if count.sum():active+=len(members)
                        for k,tau in enumerate(TAUS):offset[members,k]=weighted_inverse(rr[:,:,k].ravel(),w,tau)
            q[t]=np.maximum(b[t]+offset*sc[:,None],0)
        logs.append(dict(origin=int(o),method=f'{rule}_{sharing}',parameter=float(param),eligible_origins=len(ix),valid_residual_targets=nr,active_series=active,states=G,old_origins=int((vv[ix]!=vv[t]).sum()),latest_maturity=int(oo[ix[-1]]+H) if len(ix) else -1,fallback_all=active==0))
    assert np.isfinite(q).all() and (q>=0).all()
    return q,logs,time.perf_counter()-start
def choose(scores,default):
    return sorted(scores,key=lambda p:(scores[p],p!=default,p))[0]

