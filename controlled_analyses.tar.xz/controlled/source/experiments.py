from core import *
import argparse,psutil,gc
ROLL=['R1_global','R2_reuse','R3_isolate','R4_half'];R5='R5_multiqt_nonnegative'
def e1():
    lock=check_lock();start=time.perf_counter();allframes=[];selections=[];validation=[];costs=[]
    for source in ['m5','retail','dominicks']:
      for H in spec(next(c for c in configs() if c['source']==source))['Hs']:
       for fam in ['lgbm','mlp']:
        cs=[c for c in configs() if c['source']==source and c['horizon']==H and c['family']==fam];s=spec(cs[0]);frames=[]
        for c in cs:
            p=PRIOR/'replays'/c['case'];m=read(p/'complete.json');assert sha(p/'daily.csv')==m['daily_sha256'];frames.append(pd.read_csv(p/'daily.csv'))
            costs.append(dict(**meta(c),kind='historical_candidate_replay',seconds=m['total_seconds'],new_this_round=False))
        df=pd.concat(frames,ignore_index=True);df=df[df.base_method.isin(ROLL+[R5,'R0_raw'])].copy()
        oldsel={r['method']:r['selected'] for r in read(PRIOR/'selection'/f'{source}_h{H}_{fam}.json')['chosen']}
        for bi,block in enumerate(cs[0]['outer_blocks']):
          first,last=block['evaluation_first'],block['evaluation_last'];test=df[df.origin.between(first,last)]
          raw=test[test.base_method=='R0_raw'].copy();raw['method']='Raw';raw['protocol']='Raw';raw['block']=bi;allframes.append(raw)
          for method in ROLL+[R5]:
            default=.1 if method==R5 else s['window'];grid=[.03,.1,.3] if method==R5 else ([28,56,112] if s['unit']=='day' else [4,8,16])
            selected={'T0':default,'T1':oldsel[method]}
            for protocol,length in [('TS',28 if s['unit']=='day' else 8),('TM',84 if s['unit']=='day' else 12)]:
                vlo=block['validation_last']-length+1;vhi=block['validation_last'];vv=df[(df.base_method==method)&df.origin.between(vlo,vhi)]
                assert vv.origin.nunique()==length and vhi+H<=first
                scores={}
                for param in grid:
                    part=vv[vv.parameter==param];assert len(part)==length*2*3
                    scores[param]=float((part.scaled_pinball*part.n).sum()/part.n.sum())
                    # Three fixed long-window blocks; short windows shown as one block.
                    width=(28 if s['unit']=='day' else 4) if protocol=='TM' else length
                    for vb in range(length//width):
                        v=part[part.origin.between(vlo+vb*width,vlo+(vb+1)*width-1)]
                        validation.append(dict(source=source,H=H,family=fam,method=method,protocol=protocol,outer_block=bi,validation_block=vb,parameter=param,first=int(v.origin.min()),last=int(v.origin.max()),last_maturity=int(v.origin.max()+H),selection_origin=first,n=int(v.n.sum()),loss=float((v.scaled_pinball*v.n).sum()/v.n.sum())))
                selected[protocol]=choose(scores,default)
            for protocol,param in selected.items():
                part=test[(test.base_method==method)&(test.parameter==param)].copy();assert part.origin.nunique()==last-first+1
                part['method']=f'{method}_{protocol}';part['protocol']=protocol;part['block']=bi;allframes.append(part)
                selections.append(dict(source=source,H=H,family=fam,method=method,block=bi,protocol=protocol,parameter=param,default=default,selection_origin=first,evaluation_last=last))
        print('E1',source,H,fam,'selected using mature history',flush=True)
    dest=OUT/'E1';dest.mkdir(parents=True,exist_ok=True);pd.concat(allframes,ignore_index=True).to_parquet(dest/'daily.parquet',index=False)
    save_csv(dest/'selection.csv',selections);save_csv(dest/'validation_candidates.csv',validation);save_csv(dest/'historical_costs.csv',costs)
    write(dest/'complete.json',dict(created=now(),freeze_sha256=lock,new_replays=0,seconds=time.perf_counter()-start,daily_sha256=sha(dest/'daily.parquet'),selections=len(selections)))

def e2_case(c,pilot=False):
    lock=check_lock();dest=OUT/'E2/candidates'/c['case'];dest.mkdir(parents=True,exist_ok=True)
    if (dest/'complete.json').exists():
        d=read(dest/'complete.json');assert d['freeze_sha256']==lock;return
    start=time.perf_counter();z=case_input(c);s=spec(c);frames=[];logs=[];cost=[];files={};qraw=ordered(z['base'].astype(float))
    f=scoring(z,qraw,'Raw',c);f['parameter']=0.;frames.append(f)
    for rule in ['WQ','QT']:
      for sharing in ['series','group','global']:
       grid=([28,56,112] if s['unit']=='day' else [4,8,16]) if rule=='WQ' else [.03,.1,.3]
       for param in grid:
        q,trace,seconds=replay_control(z,c['horizon'],rule,sharing,param);method=f'{rule}_{sharing}';tag=f'{method}_p{param:g}';path=dest/(tag+'.npy')
        np.save(path,q);files[path.name]=sha(path);f=scoring(z,q,method,c);f['parameter']=float(param);frames.append(f)
        logs.extend(trace);cost.append(dict(**meta(c),method=method,parameter=param,kernel_seconds=seconds,peak_rss_gib=psutil.Process().memory_info().peak_wset/2**30))
        print('E2_CANDIDATE',c['case'],tag,round(seconds,2),flush=True)
    pd.concat(frames,ignore_index=True).to_parquet(dest/'daily.parquet',index=False);pd.DataFrame(logs).to_parquet(dest/'feedback.parquet',index=False);save_csv(dest/'costs.csv',cost)
    for name in ['daily.parquet','feedback.parquet','costs.csv']:files[name]=sha(dest/name)
    write(dest/'complete.json',dict(created=now(),freeze_sha256=lock,pilot=pilot,seconds=time.perf_counter()-start,candidates=18,files=files,peak_rss_gib=psutil.Process().memory_info().peak_wset/2**30));gc.collect()
    print('E2_COMPLETE',c['case'],round(time.perf_counter()-start,1),flush=True)
def e2_select():
    lock=check_lock();allframes=[];selections=[];validation=[];strat=[];feedback=[];cost=[];start=time.perf_counter()
    for source in ['m5','retail','dominicks']:
      for H in spec(next(c for c in configs() if c['source']==source))['Hs']:
       for fam in ['lgbm','mlp']:
        cs=[c for c in configs() if c['source']==source and c['horizon']==H and c['family']==fam];s=spec(cs[0]);dfs=[]
        for c in cs:
            p=OUT/'E2/candidates'/c['case'];cm=read(p/'complete.json');assert cm['freeze_sha256']==lock
            for name,h in cm['files'].items():assert sha(p/name)==h
            dfs.append(pd.read_parquet(p/'daily.parquet'));cost.extend(pd.read_csv(p/'costs.csv').to_dict('records'))
        df=pd.concat(dfs,ignore_index=True);choices={}
        for bi,block in enumerate(cs[0]['outer_blocks']):
          for method in [f'{r}_{l}' for r in ['WQ','QT'] for l in ['series','group','global']]:
           for tau in TAUS:
            v=df[(df.method==method)&(df['quantile']==tau)&df.origin.between(block['validation_first'],block['validation_last'])]
            scores={}
            for param,part in v.groupby('parameter'):
                assert part.seed.nunique()==3 and part.origin.nunique()==block['validation_origins']
                scores[param]=float((part.scaled_pinball*part.n).sum()/part.n.sum())
                validation.append(dict(source=source,H=H,family=fam,method=method,block=bi,quantile=tau,parameter=param,loss=scores[param],first=block['validation_first'],last=block['validation_last'],last_maturity=block['validation_last']+H,selection_origin=block['selection_origin']))
            default=s['window'] if method.startswith('WQ') else .1;param=choose(scores,default);choices[method,bi,float(tau)]=param
            selections.append(dict(source=source,H=H,family=fam,method=method,block=bi,quantile=tau,parameter=param,default=default,selection_origin=block['selection_origin']))
        for c in cs:
            z=case_input(c);mask=np.zeros(len(z['origins']),bool);p=OUT/'E2/candidates'/c['case'];trace=pd.read_parquet(p/'feedback.parquet')
            for block in c['outer_blocks']:mask|=(z['origins']>=block['evaluation_first'])&(z['origins']<=block['evaluation_last'])
            allframes.append(scoring(z,ordered(z['base'].astype(float)),'Raw',c,mask));strat.extend(strata(z,ordered(z['base'].astype(float)),'Raw',c,mask))
            for method in [f'{r}_{l}' for r in ['WQ','QT'] for l in ['series','group','global']]:
                q=ordered(z['base'].astype(float));opened={}
                for bi,block in enumerate(c['outer_blocks']):
                    take=(z['origins']>=block['evaluation_first'])&(z['origins']<=block['evaluation_last'])
                    for k,tau in enumerate(TAUS):
                        param=choices[method,bi,float(tau)]
                        if param not in opened:opened[param]=np.load(p/f'{method}_p{param:g}.npy',mmap_mode='r')
                        q[take,:,k]=opened[param][take,:,k]
                        ff=trace[(trace.method==method)&(trace.parameter==param)&trace.origin.between(block['evaluation_first'],block['evaluation_last'])].copy();ff['quantile']=tau;ff['block']=bi
                        for key,value in meta(c).items():ff[key]=value
                        feedback.extend(ff.to_dict('records'))
                allframes.append(scoring(z,q,method,c,mask));allframes.append(scoring(z,np.sort(q,axis=-1),method+'_sorted',c,mask));strat.extend(strata(z,q,method,c,mask));strat.extend(strata(z,np.sort(q,axis=-1),method+'_sorted',c,mask))
                del opened
            print('E2_SELECTED',c['case'],flush=True)
    dest=OUT/'E2';pd.concat(allframes,ignore_index=True).to_parquet(dest/'daily.parquet',index=False);save_csv(dest/'selection.csv',selections);save_csv(dest/'validation_candidates.csv',validation);pd.DataFrame(strat).to_parquet(dest/'strata.parquet',index=False);pd.DataFrame(feedback).to_parquet(dest/'feedback_selected.parquet',index=False);save_csv(dest/'costs.csv',cost)
    write(dest/'complete.json',dict(created=now(),freeze_sha256=lock,seconds=time.perf_counter()-start,daily_sha256=sha(dest/'daily.parquet'),selections=len(selections)))

def pair_predictions(y,old,new,sc,groups,oo,H,window):
    """Matched post-switch references; both arms calibrate the same new baseline."""
    b=ordered(new.astype(float));refs=[ordered(old.astype(float)),b];outputs=[b.copy(),b.copy()];logs=[]
    for ai,reference in enumerate(refs):
        res=(y[:,:,None]-reference)/sc[None,:,None]
        for t,o in enumerate(oo):
            ix=np.flatnonzero((oo+H<=o)&(oo>=o-window));pre=b[t].copy();active=0;nr=int(np.isfinite(y[ix]).sum())
            for g in np.unique(groups):
                take=groups==g;rr=res[ix][:,take]
                if len(ix) and np.isfinite(rr).any():
                    active+=int(take.sum())
                    for k,tau in enumerate(TAUS):
                        v=rr[:,:,k].ravel();v=v[np.isfinite(v)]
                        if len(v):pre[take,k]+=float(np.quantile(v,tau,method='higher'))*sc[take]
            outputs[ai][t]=ordered(pre)
            logs.append(dict(origin=int(o),arm='old_reference' if ai==0 else 'new_reference',eligible_origins=len(ix),valid_residual_targets=nr,active_series=active,latest_maturity=int(oo[ix[-1]]+H) if len(ix) else -1,fallback_all=active==0))
    return outputs,logs
def e3_case(c,pilot=False):
    lock=check_lock();dest=OUT/'E3/cases'/c['case'];dest.mkdir(parents=True,exist_ok=True)
    if (dest/'complete.json').exists():assert read(dest/'complete.json')['freeze_sha256']==lock;return
    start=time.perf_counter();z=case_input(c);s=spec(c);H=c['horizon'];U=c['update_interval'];bank=BASE/'banks'/c['source']/f'h{H}_{c["family"]}_s{c["seed"]}_hist{s["history"]}_delay0'
    cuts=[s['initial_cutoff']]+list(range(s['eval_start'],s['eval_end']+1,U));qs={m:ordered(z['base'].astype(float)) for m in ['Raw','old_reference','new_reference']};logs=[];pairs=[];events=[]
    old=load(bank/f'c{cuts[0]}'/'predictions.npz')
    for oldcut,newcut in zip(cuts[:-1],cuts[1:]):
        new=load(bank/f'c{newcut}'/'predictions.npz');oo=np.arange(newcut,min(newcut+U,s['eval_end']+1));ii=np.searchsorted(z['origins'],oo);oi=np.searchsorted(old['origins'],oo);ni=np.searchsorted(new['origins'],oo)
        np.testing.assert_array_equal(old['origins'][oi],oo);np.testing.assert_array_equal(new['origins'][ni],oo);np.testing.assert_array_equal(z['base'][ii],new['base'][ni])
        out,trace=pair_predictions(z['truth'][ii],old['base'][oi],new['base'][ni],z['scale'],z['groups'],oo,H,s['window'])
        for method,q in zip(['old_reference','new_reference'],out):qs[method][ii]=q
        for row in trace:row.update(**meta(c),old_cutoff=oldcut,new_cutoff=newcut)
        logs.extend(trace);pairs.append(dict(**meta(c),old_cutoff=oldcut,new_cutoff=newcut,n_origins=len(oo),n_pair_targets=int(np.isfinite(z['truth'][ii]).sum()),mature_prediction_origins=max(0,len(oo)-H),partial_event=len(oo)<U))
        mask=np.isin(z['origins'],oo)
        for method,q in qs.items():
            f=scoring(z,q,method,c,mask)
            for tau,g in f.groupby('quantile'):
                den=g.n.sum();events.append(dict(**meta(c),method=method,new_cutoff=newcut,quantile=tau,n=int(den),**{m:float((g[m]*g.n).sum()/den) if den else np.nan for m in METRICS}))
        old=new
    mask=z['origins']>=s['eval_start'];df=[];strat=[]
    for method,q in qs.items():
        f=scoring(z,q,method,c,mask);f['active_phase']=(f.origin-f.origin.map(lambda o:cuts[max(1,np.searchsorted(cuts,o,side='right')-1)]))>=H;df.append(f);strat.extend(strata(z,q,method,c,mask))
    pd.concat(df,ignore_index=True).to_parquet(dest/'daily.parquet',index=False);pd.DataFrame(logs).to_parquet(dest/'feedback.parquet',index=False);save_csv(dest/'pairs.csv',pairs);save_csv(dest/'events.csv',events);pd.DataFrame(strat).to_parquet(dest/'strata.parquet',index=False)
    np.savez_compressed(dest/'predictions.npz',**{k:v[mask] for k,v in qs.items()},origins=z['origins'][mask])
    write(dest/'complete.json',dict(**meta(c),created=now(),freeze_sha256=lock,pilot=pilot,seconds=time.perf_counter()-start,pairs=len(pairs),peak_rss_gib=psutil.Process().memory_info().peak_wset/2**30,files={p.name:sha(p) for p in dest.iterdir() if p.is_file() and p.name!='complete.json'}))
    print('E3_COMPLETE',c['case'],len(pairs),round(time.perf_counter()-start,2),flush=True)
def run(pilot=False):
    for c in configs():
        if pilot and not(c['seed']==SEEDS[0] and c['horizon']==max(spec(c)['Hs'])):continue
        e2_case(c,pilot);e3_case(c,pilot)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['e1','pilot','run','select']);a=ap.parse_args();{'e1':e1,'pilot':lambda:run(True),'run':run,'select':e2_select}[a.mode]()
