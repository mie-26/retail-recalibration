from core import *
from analyze import contrast,vector,boot_weights
import argparse
FIELDS=['source','H','U','family']
def summarize(df,extra=None):
    rows=[];keys=FIELDS+['method','quantile']+(extra or [])
    for key,g in df.groupby(keys,dropna=False):
        den=g.n.sum();r=dict(zip(keys,key));r.update(n_seeds=g.seed.nunique(),n_pairs_per_seed=den/max(1,g.seed.nunique()),**{m:float(np.nansum(g[m]*g.n)/den) if den else np.nan for m in METRICS})
        r['bracket_distance']=max(r['strict']-r['quantile'],r['quantile']-r['weak'],0);r['crossing']=float(np.nansum(g.crossing*g.n)/den) if 'crossing' in g and den else np.nan;rows.append(r)
    return pd.DataFrame(rows)
def effect(a,b):
    oa,n,av,names=vector(a);ob,nb,bv,_=vector(b);np.testing.assert_array_equal(oa,ob);np.testing.assert_array_equal(n,nb)
    aa=(np.nan_to_num(av)*n[:,None]).sum(0)/n.sum();bb=(np.nan_to_num(bv)*n[:,None]).sum(0)/n.sum()
    return dict(n_origins=len(oa),n_pairs=n.sum(),candidate_joint=aa[0],reference_joint=bb[0],relative_loss_pct=100*(aa[0]/bb[0]-1),q90_weak_difference=100*(aa[4]-bb[4]),q95_weak_difference=100*(aa[5]-bb[5]))
def comparisons(kind):
    if kind=='E1':
        methods=['R1_global','R2_reuse','R3_isolate','R4_half','R5_multiqt_nonnegative']
        pairs=[(f'{m}_TM',f'{m}_{p}','selection_history') for m in methods for p in ['TS','T1','T0']]
        pairs += [(f'{m}_{p}','Raw','vs_Raw') for m in methods for p in ['T0','T1','TS','TM']]
        pairs += [(f'R5_multiqt_nonnegative_{p}',f'R2_reuse_{p}','legacy_rule_comparison') for p in ['T0','T1','TS','TM']]
        return pairs
    if kind=='E2':
        methods=[f'{r}_{l}' for r in ['WQ','QT'] for l in ['series','group','global']]
        return ([(m,'Raw','vs_Raw') for m in methods]+[(f'{r}_{a}',f'{r}_{b}','sharing') for r in ['WQ','QT'] for a,b in [('group','series'),('global','group')]]+[(f'QT_{l}',f'WQ_{l}','rule') for l in ['series','group','global']]+[(m+'_sorted',m,'scoring_only_sort') for m in methods]+[(m+'_sorted','Raw','sorted_vs_Raw') for m in methods])
    return [('old_reference','Raw','old_vs_Raw'),('new_reference','Raw','new_vs_Raw'),('new_reference','old_reference','reference_version')]
def e3_gather():
    bags={n:[] for n in ['daily','feedback','strata','pairs','events']};cost=[]
    for c in configs():
        p=OUT/'E3/cases'/c['case'];m=read(p/'complete.json');assert m['freeze_sha256']==check_lock()
        for name,h in m['files'].items():assert sha(p/name)==h
        for n in ['daily','feedback','strata']:bags[n].append(pd.read_parquet(p/f'{n}.parquet'))
        for n in ['pairs','events']:bags[n].append(pd.read_csv(p/f'{n}.csv'))
        cost.append({k:m[k] for k in ['source','H','U','family','seed','case','seconds','peak_rss_gib']})
    for n,frames in bags.items():
        allf=pd.concat(frames,ignore_index=True)
        if n in ['pairs','events']:save_csv(OUT/'E3'/f'{n}.csv',allf)
        else:allf.to_parquet(OUT/'E3'/f'{n}.parquet',index=False)
    save_csv(OUT/'E3/costs.csv',cost)
def interaction(df):
    points=[];intervals=[]
    for key,g in df.groupby(FIELDS):
        m=dict(zip(FIELDS,key));H=m['H'];s=spec(next(c for c in configs() if c['source']==m['source']))
        oo,n,raw,_=vector(g[g.method=='Raw']);rawnum=np.nan_to_num(raw[:,0])*n
        for a,b in [('group','series'),('global','group')]:
            nums={}
            for method in [f'{r}_{l}' for r in ['QT','WQ'] for l in [a,b]]:
                o,nn,v,_=vector(g[g.method==method]);np.testing.assert_array_equal(oo,o);np.testing.assert_array_equal(n,nn);nums[method]=np.nan_to_num(v[:,0])*n
            delta=nums['QT_'+a]-nums['QT_'+b]-nums['WQ_'+a]+nums['WQ_'+b]
            point=100*delta.sum()/rawnum.sum();mm=dict(**m,sharing_contrast=a+'-'+b,rule_contrast='QT-WQ',interaction_pct_of_Raw=point);points.append(mm)
            for L in sorted(set([H,2*H,4*H,56 if s['unit']=='day' else 8])):
                if len(oo)<4*L:continue
                w=boot_weights(len(oo),L);v=100*(w@delta)/(w@rawnum);lo,hi=np.quantile(v,[.025,.975]);intervals.append(dict(**mm,block_length=L,primary=L==2*H,lower=lo,upper=hi,draws=3000))
    save_csv(OUT/'tables/E2_interactions.csv',points);save_csv(OUT/'tables/E2_interaction_intervals.csv',intervals)
def main():
    lock=check_lock();start=time.perf_counter();e3_gather();counts={};allpoints=[];allci=[];allseed=[];allthird=[];allnonoverlap=[]
    for kind in ['E1','E2','E3']:
        df=pd.read_parquet(OUT/kind/'daily.parquet');assert df.case.nunique()==36;save_csv(OUT/'tables'/f'{kind}_quantile_scores.csv',summarize(df));counts[kind]=len(df)
        if kind=='E2':interaction(df)
        for key,g in df.groupby(FIELDS):
            mm=dict(zip(FIELDS,key));H=mm['H'];unit='week' if mm['source']=='dominicks' else 'day';oo=np.sort(g.origin.unique())
            scopes=['all','mature_phase'] if kind=='E3' else ['all']
            for scope in scopes:
                gg=g.copy()
                if scope=='mature_phase':
                    # Preserve the full calendar grid for resampling. Zero weight at inactive dates.
                    gg.loc[~gg.active_phase,'n']=0
                for ca,ref,reason in comparisons(kind):
                    a=gg[gg.method==ca];b=gg[gg.method==ref];m=dict(**mm,experiment=kind,scope=scope,candidate=ca,reference=ref,comparison=reason)
                    pt,ci=contrast(a,b,m,H,unit);allpoints.append(pt);allci.extend(ci)
                    for seed in SEEDS:allseed.append(dict(**m,seed=seed,**effect(a[a.seed==seed],b[b.seed==seed])))
                    for period,dates in enumerate(np.array_split(oo,3)):
                        aa=a[a.origin.isin(dates)];bb=b[b.origin.isin(dates)]
                        if aa.n.sum():
                            pp,ii=contrast(aa,bb,dict(**m,period=period),H,unit);allthird.append(pp)
                            # Segment intervals are kept only with the same minimum-block rule.
                            for row in ii:row['scope']=scope+'_segment';allci.append(row)
                    if scope=='all':
                        for offset in range(H):
                            aa=a[(a.origin-oo[0])%H==offset];bb=b[(b.origin-oo[0])%H==offset]
                            if aa.n.sum():allnonoverlap.append(dict(**m,offset=offset,**effect(aa,bb)))
            print('ANALYZE',kind,mm,flush=True)
        if kind in ['E2','E3']:
            f=pd.read_parquet(OUT/kind/'strata.parquet');save_csv(OUT/'tables'/f'{kind}_strata.csv',summarize(f,['field','stratum']))
    save_csv(OUT/'tables/effects.csv',allpoints);save_csv(OUT/'tables/intervals.csv',allci);save_csv(OUT/'tables/seed_effects.csv',allseed);save_csv(OUT/'tables/segment_effects.csv',allthird);save_csv(OUT/'tables/nonoverlap_effects.csv',allnonoverlap)
    write(OUT/'analysis_complete.json',dict(created=now(),freeze_sha256=lock,rows=counts,contrasts=len(allpoints),interval_rows=len(allci),nonoverlap_rows=len(allnonoverlap),seconds=time.perf_counter()-start,new_base_fits=0,evidence='Post-review controlled analysis, no new independent confirmation'))
    print('ANALYSIS_COMPLETE',len(allpoints),round(time.perf_counter()-start,1),flush=True)
if __name__=='__main__':main()
