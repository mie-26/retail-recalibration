from core import *
import argparse,platform
def run():
    started=time.perf_counter();rows=[];files={};pairs=0
    for c in configs():
        s=spec(c);H=c['horizon'];U=c['update_interval'];p=BASE/'replays/core'/c['case'];cm=read(p/'complete.json');z=load(p/'input.npz')
        assert sha(p/'input.npz')==cm['files']['input.npz'];files[str((p/'input.npz').relative_to(ROOT))]=sha(p/'input.npz')
        assert np.isfinite(z['base']).all() and np.isfinite(z['scale']).all() and (z['scale']>=1).all()
        assert (np.diff(z['origins'])==1).all();selp=BASE/'selection'/f'{c["source"]}_h{H}_{c["family"]}'/'selected.json';sel=read(selp)
        assert z['origins'][0]>sel['validation_last_target'];files[str(selp.relative_to(ROOT))]=sha(selp)
        panel=BASE/'panels'/c['source'];yy=np.load(panel/'y.npy',mmap_mode='r');cohort=pd.read_csv(panel/'cohort.csv');np.testing.assert_array_equal(z['groups'],cohort.group)
        assert len(cohort)==z['base'].shape[1] and z['base'].shape==(*z['truth'].shape,2)
        target=np.array([yy[:,o:o+H].sum(1) for o in z['origins']],dtype='float32');np.testing.assert_array_equal(target,z['truth'])
        lo=max(s['lookback'],s['initial_cutoff']-s['history']-H+1)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            sc=np.maximum(1,np.nanmean(np.array([yy[:,o:o+H].sum(1) for o in range(lo,s['initial_cutoff']-H+1)],dtype='float32'),axis=0)).astype('float32');sc=np.nan_to_num(sc,nan=1.)
        np.testing.assert_array_equal(sc,z['scale'])
        for name,h in s['sha256'].items():
            path=panel/name;key=str(path.relative_to(ROOT))
            if key not in files:assert sha(path)==h;files[key]=h
        bank=BASE/'banks'/c['source']/f'h{H}_{c["family"]}_s{c["seed"]}_hist{s["history"]}_delay0'
        cuts=[s['initial_cutoff']]+list(range(s['eval_start'],s['eval_end']+1,U));previous=None;casepairs=[]
        for cut in cuts:
            bp=bank/f'c{cut}';m=read(bp/'complete.json');bz=load(bp/'predictions.npz')
            assert sha(bp/'predictions.npz')==m['prediction_sha256'];files[str((bp/'predictions.npz').relative_to(ROOT))]=m['prediction_sha256']
            files[str((bp/'complete.json').relative_to(ROOT))]=sha(bp/'complete.json')
            for name,h in m['model_sha256'].items():assert sha(bp/name)==h;files[str((bp/name).relative_to(ROOT))]=h
            assert m['configuration']==sel['configuration'];a=m['training'];assert a['last_origin']+H==a['last_target']<=cut
            assert np.isfinite(bz['base']).all() and bz['base'].shape[1:]==z['base'].shape[1:]
            assert bz['origins'][0]>=cut and (np.diff(bz['origins'])==1).all()
            take=z['versions']==cut;ix=np.searchsorted(bz['origins'],z['origins'][take]);np.testing.assert_array_equal(bz['origins'][ix],z['origins'][take]);np.testing.assert_array_equal(bz['base'][ix],z['base'][take])
            if previous is not None:
                oo=np.arange(cut,min(cut+U,s['eval_end']+1));assert np.isin(oo,previous['origins']).all() and np.isin(oo,bz['origins']).all();pairs+=1;casepairs.append(dict(new=cut,origins=len(oo)))
            previous=bz
        prior=PRIOR/'replays'/c['case'];pm=read(prior/'complete.json');assert pm['input_sha256']==cm['files']['input.npz'];assert sha(prior/'daily.csv')==pm['daily_sha256'];files[str((prior/'daily.csv').relative_to(ROOT))]=pm['daily_sha256']
        files[str((prior/'complete.json').relative_to(ROOT))]=sha(prior/'complete.json')
        selection=PRIOR/'selection'/f'{c["source"]}_h{H}_{c["family"]}.json';files[str(selection.relative_to(ROOT))]=sha(selection)
        for block in c['outer_blocks']:
            assert block['validation_last']+H<=block['selection_origin'] and block['evaluation_first']==block['selection_origin']
            assert block['validation_first']>=s['eval_start']
        rows.append(dict(**meta(c),n_series=len(cohort),n_versions=len(cuts),pairs=len(casepairs),target_identity=True,scale_identity=True,bank_base_identity=True,training_cutoffs_valid=True,feature_rule='lags and windows end origin-1; frozen static inputs from initial cutoff; each model owns preprocessing',prediction_hashes_match=True))
        print('PREFLIGHT',c['case'],'OK',flush=True)
    assert len(rows)==36 and pairs==564
    write(OUT/'preflight.json',dict(created=now(),status='PASS',new_fits=0,configurations=rows,paired_events=pairs,seconds=time.perf_counter()-started,files=files,limits='Hash and exact cached-array identity with reconstructed targets/scales; no new full model inference. Feature causality audited from source and mutation tests.'))
    print('PREFLIGHT_COMPLETE',len(files),round(time.perf_counter()-started,2),flush=True)
def freeze():
    pre=read(OUT/'preflight.json');assert pre['status']=='PASS'
    tests=read(OUT/'tests.json');assert tests['failed']==0
    files=list(HERE.glob('*.py'))+[ROOT/'work/sr_enhanced/common.py',ROOT/'work/sr_enhanced/calibration.py',ROOT/'work/sr_enhanced/models.py',ROOT/'work/sr_enhanced/analyze.py',ROOT/'work/sr_strengthening_20261025/experiment.py']
    protocol=read(PROPOSED);protocol.update(status='FROZEN',new_experiments_run=False,ready_to_execute=True)
    protocol['implementation_clarifications']={'E1':'reuse hash-verified original full continuous-candidate daily scores; no dynamic-state splice; validation all within their cached support','E2_sort':'select unsorted q90 and q95 separately, then postprocess same selected pair for scoring only','E3':'post-switch feedback only; H-period Raw fallback; legacy higher empirical quantile and final sorting','pilot':'six first-seed long-horizon configurations, resource/correctness only; included in full matrix with identical locked code','selection_ties':'exact numerical equality: default then smaller','intervals':'conditional on fitted and selected paths; matched circular whole-date blocks, 3000 draws seed 20261021','new_base_fits':0}
    dest=OUT/'freeze_manifest.json';assert not dest.exists(),'Do not overwrite frozen protocol'
    write(dest,dict(status='FROZEN',created=now(),protocol=protocol,proposed_sha256=sha(PROPOSED),preflight_sha256=sha(OUT/'preflight.json'),tests_sha256=sha(OUT/'tests.json'),code_sha256={str(p.relative_to(ROOT)):sha(p) for p in files},python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,new_base_fits=0))
    print('FROZEN',sha(dest),flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['run','freeze']);a=ap.parse_args();{'run':run,'freeze':freeze}[a.mode]()
