"""Post-run numerical audit only; no model/method/selection changes."""
from common import *
from model_bank import Design,assemble
from fitters import predict,network,torch_import
import lightgbm as lgb
def main():
    digest=lock();assert (OUT/'run_complete.json').exists();checks=[]
    # Every stored bank file must match its completion record and legal training cutoff.
    jobs=[]
    for p in (OUT/'bank').glob('*/*/complete.json'):
        m=read(p);assert m['freeze_sha256']==digest
        for n,h in m['file_sha256'].items():assert sha(p.parent/n)==h
        assert m['training']['last_target_count']<=m['cutoff'];jobs.append(m)
    assert len(jobs)==468 and sum(m['base_model_count'] for m in jobs)==702
    checks.append(dict(check='all_bank_hashes_and_training_maturity',passed=True,fit_jobs=len(jobs),base_models=702))
    # Re-infer first and last bank models for each family/H at first seed.
    for H in [7,14]:
     d=Design(H)
     for family in ['lgbm','mlp']:
      for cut in [int(cuts()[0]),int(cuts()[-1])]:
        p=OUT/'bank'/f'h{H}_{family}_s{SEEDS[0]}'/f'c{cut}';z=load(p/'predictions.npz');ix=np.unique([0,len(z['origins'])-1]);oo=z['origins'][ix];x=d.make(oo)
        if family=='lgbm':model=[lgb.Booster(model_file=str(p/f'q{int(t*100)}.txt')) for t in TAUS]
        else:
            torch=torch_import();r=torch.load(p/'model.pt',map_location='cpu',weights_only=False);net=network(torch,r['F'],r['width']).cuda();net.load_state_dict(r['state']);model=(net,r['mean'],r['sd'])
        got=predict(model,x.reshape(-1,x.shape[-1]),family).reshape(len(oo),d.n,2)*d.scale[None,:,None]
        np.testing.assert_allclose(got,z['base'][ix],rtol=2e-6,atol=2e-6);checks.append(dict(check='saved_model_reinference',H=H,family=family,cutoff=cut,max_absolute_error=float(np.max(np.abs(got-z['base'][ix])))))
    # Reconstruct all fixed predictions from selected, seed-shared parameter logs.
    sel=pd.read_csv(OUT/'selected/selections.csv');daily=pd.read_parquet(OUT/'selected/daily.parquet')
    for c in configs():
      p=OUT/'candidates'/c['case'];z=load(p/'input.npz');oo=z['origins'];mask=oo>=FIRST
      for method in [f'{r}_{s}' for r in ['QT','WQ'] for s in ['series','group','global']]:
       for length in [28,84]:
        q=np.load(OUT/'selected'/f'{c["case"]}_{method}_L{length}.npy');ss=sel[(sel.H==c['H'])&(sel.U==c['U'])&(sel.family==c['family'])&(sel.method==method)&(sel.length==length)]
        for r in ss.itertuples():
            k=int(np.flatnonzero(TAUS==r.quantile)[0]);take=(oo[mask]>=r.selection_origin)&(oo[mask]<r.selection_origin+56);cand=np.load(p/f'{method}_p{r.parameter:g}.npy',mmap_mode='r')
            np.testing.assert_array_equal(q[take,:,k],cand[mask][take,:,k])
      tr=pd.read_parquet(p/'feedback.parquet');assert (tr.latest_maturity<=tr.origin).all()
      iso=tr[(tr.method=='R3_isolate')&(tr.origin>=FIRST)];assert (iso.old_origins==0).all()
      n= np.isfinite(z['truth'][mask]).sum(1);raw=daily[(daily.case==c['case'])&(daily.method=='Raw')&(daily['quantile']==.9)].sort_values('origin');np.testing.assert_array_equal(raw.n,n)
    checks.append(dict(check='all_selected_state_promotions_and_masks',passed=True,configs=24,selected_paths=288))
    freeze=read(OUT/'freeze_manifest.json');access=read(OUT/'protected_access.json');assert freeze['frozen_at']<access['first_numeric_access_at']
    checks.append(dict(check='freeze_precedes_first_protected_numeric_access',passed=True))
    write(OUT/'verification.json',dict(created=now(),freeze_sha256=digest,checks=checks,all_passed=True,note='Post-run audit;8 model jobs re-inferred,all468 bank hashes/training cutoffs checked. No new fits.'))
    print('VERIFICATION_PASSED',len(checks),flush=True)
if __name__=='__main__':main()
