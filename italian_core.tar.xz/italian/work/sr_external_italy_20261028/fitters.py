from common import *
import lightgbm as lgb

def torch_import():
    import torch
    torch.set_num_threads(4)
    return torch

def pinloss(y,q):
    e=y[:,None]-q;return np.nanmean(np.maximum(e*TAUS,e*(TAUS-1)))

def lgb_fit(x,y,seed,rounds,path=None):
    models=[];t=time.perf_counter()
    for tau in TAUS:
        params=dict(objective='quantile',alpha=float(tau),learning_rate=.05,num_leaves=31,min_data_in_leaf=100,max_bin=127,verbosity=-1,num_threads=8,seed=seed,feature_fraction=.9,bagging_fraction=.9,bagging_freq=1,deterministic=True,force_col_wise=True)
        m=lgb.train(params,lgb.Dataset(x,label=y,free_raw_data=False),num_boost_round=rounds);models.append(m)
        if path:m.save_model(str(path/f'q{int(tau*100)}.txt'))
    return models,time.perf_counter()-t

def network(torch,F,width):
    return torch.nn.Sequential(torch.nn.Linear(F,width),torch.nn.ReLU(),torch.nn.Linear(width,width),torch.nn.ReLU(),torch.nn.Linear(width,2),torch.nn.Softplus())

def mlp_fit(x,y,seed,width,epochs,path=None,val=None):
    torch=torch_import();torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True);device='cuda';assert torch.cuda.is_available()
    mean=x.mean(0,dtype='float64').astype('float32');sd=x.std(0,dtype='float64').astype('float32');sd=np.maximum(sd,.001)
    xx=torch.tensor(np.clip((x-mean)/sd,-20,20),device=device);yy=torch.tensor(y[:,None],device=device)
    net=network(torch,x.shape[1],width).to(device);opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0001)
    taus=torch.tensor(TAUS.astype('float32'),device=device);records=[];states={};start=time.perf_counter()
    batch=4096
    for epoch in range(1,epochs+1):
        net.train();order=torch.randperm(len(y),device=device)
        for begin in range(0,len(y),batch):
            ix=order[begin:begin+batch];q=net(xx[ix]);e=yy[ix]-q;loss=torch.maximum(e*taus,e*(taus-1)).mean()
            opt.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),5.);opt.step()
        if val is not None and epoch in [5,10,20]:
            pred=mlp_predict(net,mean,sd,val[0],torch);score=pinloss(val[1],np.sort(pred,axis=1))
            records.append(dict(width=width,epochs=epoch,validation_loss=score));states[epoch]={k:v.detach().cpu().clone() for k,v in net.state_dict().items()}
    torch.cuda.synchronize();seconds=time.perf_counter()-start
    if path:torch.save(dict(state=net.cpu().state_dict(),mean=mean,sd=sd,F=x.shape[1],width=width),path/'model.pt')
    del xx,yy;torch.cuda.empty_cache()
    return (net.to(device),mean,sd),seconds,records,states

def mlp_predict(net,mean,sd,x,torch=None):
    if torch is None:torch=torch_import()
    net.eval();result=[]
    with torch.no_grad():
        for i in range(0,len(x),32768):
            v=torch.tensor(np.clip((x[i:i+32768]-mean)/sd,-20,20),device='cuda');result.append(net(v).cpu().numpy())
    return np.concatenate(result)

def predict(model,x,family,rounds=None):
    if family=='lgbm':return np.column_stack([m.predict(x,num_iteration=rounds,num_threads=8) for m in model])
    return mlp_predict(*model,x)

