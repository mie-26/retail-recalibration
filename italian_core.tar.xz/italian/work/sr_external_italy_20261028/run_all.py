"""Resume-safe orchestrator; logs progress only, no confirmation rankings before completion."""
from common import *
import subprocess
def command(script,args,log):
    with (OUT/log).open('a',encoding='utf8') as f:
        p=subprocess.Popen([sys.executable,'-u',str(HERE/script),*args],stdout=f,stderr=subprocess.STDOUT,cwd=ROOT)
    return p
def main():
    digest=lock();start=time.perf_counter()
    from intake import unlock
    unlock()
    jobs=[command('model_bank.py',[f],f'bank_{f}.log') for f in ['lgbm','mlp']]
    for p in jobs:assert p.wait()==0,'model bank process failed; inspect logs'
    jobs=[command('replay.py',['run','--family',f],f'replay_{f}.log') for f in ['lgbm','mlp']]
    for p in jobs:assert p.wait()==0,'replay process failed; inspect logs'
    assert command('replay.py',['select'],'selection.log').wait()==0
    assert command('analysis.py',[],'statistics.log').wait()==0
    write(OUT/'run_complete.json',dict(created=now(),freeze_sha256=digest,wall_seconds=time.perf_counter()-start))
if __name__=='__main__':
    try:main()
    except Exception as e:write(OUT/'run_failure.json',dict(created=now(),error=str(e)));raise
