from common import *
from kernels import replay_control,choose,pair_predictions
from legacy import replay as legacy_replay,daily_scores
from model_bank import assemble
import argparse,gc
METRICS=['scaled_pinball','pinball','weak','strict','equality','zero_tie']
METHODS=[f'{r}_{s}' for r in ['WQ','QT'] for s in ['series','group','global']]
def scoring(z,q,method,c,mask=None):
    ix=np.arange(len(q)) if mask is None else np.flatnonzero(mask);a=daily_scores(z['truth'][ix],q[ix],z['scale']);rows=[]
    for k,tau in enumerate(TAUS):
        part=pd.DataFrame(dict(origin=z['origins'][ix],quantile=tau,n=a['n'],method=method,**{m:a[m][:,k] for m in METRICS}))
        part['date']=[str(DATES[o-1].date()) for o in part.origin];part['version']=z['versions'][ix]
        part['phase']=np.where(part.origin-part.version<c['H'],'1_H',np.where(part.origin-part.version<2*c['H'],'H1_2H','later'))
        part['crossing']=np.mean(q[ix,:,0]>q[ix,:,1],axis=1)
        for key,value in c.items():part[key]=value
        rows.append(part)
    return pd.concat(rows,ignore_index=True)
def verify_done(p,digest):
    if not (p/'complete.json').exists():return False
    m=read(p/'complete.json');assert m['freeze_sha256']==digest
    for n,h in m['files'].items():assert sha(p/n)==h
    return True
def candidates(c):
    digest=lock();p=OUT/'candidates'/c['case'];p.mkdir(parents=True,exist_ok=True)
    if verify_done(p,digest):return
    z=assemble(c);np.savez_compressed(p/'input.npz',**z);frames=[scoring(z,ordered(z['base']),'Raw',c)];frames[0]['parameter']=0.
    logs=[];cost=[];started=time.perf_counter()
    for rule in ['WQ','QT']:
      for sharing in ['series','group','global']:
       for param in ([28,56,112] if rule=='WQ' else [.03,.1,.3]):
        q,tr,sec=replay_control(z,c['H'],rule,sharing,param);method=f'{rule}_{sharing}'
        np.save(p/f'{method}_p{param:g}.npy',q);f=scoring(z,q,method,c);f['parameter']=float(param);frames.append(f);logs.extend(tr)
        cost.append(dict(method=method,parameter=param,seconds=sec));del q
    for method in ['R2_reuse','R3_isolate']:
        q,tr,sec=legacy_replay(z['truth'],z['base'],z['scale'],z['groups'],z['origins'],z['versions'],c['H'],method,window=56)
        np.save(p/f'{method}.npy',q);f=scoring(z,q,method,c);f['parameter']=56.;frames.append(f)
        for r in tr:r.update(method=method,parameter=56.)
        logs.extend(tr);cost.append(dict(method=method,parameter=56,seconds=sec));del q
    pd.concat(frames).to_parquet(p/'daily.parquet',index=False);pd.DataFrame(logs).to_parquet(p/'feedback.parquet',index=False);csv(p/'costs.csv',cost)
    write(p/'complete.json',dict(freeze_sha256=digest,created=now(),seconds=time.perf_counter()-started,files={f.name:sha(f) for f in p.iterdir() if f.is_file() and f.name!='complete.json'}))
    print('CANDIDATE_REPLAY_COMPLETE',c['case'],round(time.perf_counter()-started,1),flush=True);gc.collect()
def e3(c):
    digest=lock();p=OUT/'e3'/c['case'];p.mkdir(parents=True,exist_ok=True)
    if verify_done(p,digest):return
    z=load(OUT/'candidates'/c['case']/'input.npz');oo=z['origins'];qs={m:ordered(z['base']) for m in ['Raw','old_reference','new_reference']};traces=[];pairs=[]
    calendar=cuts(c['U']);started=time.perf_counter()
    for prev,cur in zip(calendar[:-1],calendar[1:]):
        ix=np.flatnonzero((oo>=cur)&(oo<cur+c['U']));orig=oo[ix]
        bank=OUT/'bank'/f'h{c["H"]}_{c["family"]}_s{c["seed"]}'
        old=load(bank/f'c{prev}/predictions.npz');oi=orig-prev;np.testing.assert_array_equal(old['origins'][oi],orig)
        old_b=old['base'][oi];new_b=z['base'][ix];res,tr=pair_predictions(z['truth'][ix],old_b,new_b,z['scale'],z['groups'],orig,c['H'],56)
        for m,q in zip(['old_reference','new_reference'],res):qs[m][ix]=q
        for r in tr:r.update(old_cutoff=int(prev),new_cutoff=int(cur))
        traces.extend(tr);pairs.append(dict(old_cutoff=int(prev),new_cutoff=int(cur),origins=len(orig),same_origin_assertion=True,retained_old_preprocessing=True))
    frames=[scoring(z,q,m,c,oo>=FIRST) for m,q in qs.items()];pd.concat(frames).to_parquet(p/'daily.parquet',index=False)
    pd.DataFrame(traces).to_parquet(p/'feedback.parquet',index=False);csv(p/'pairs.csv',pairs);np.savez_compressed(p/'predictions.npz',**qs)
    write(p/'complete.json',dict(freeze_sha256=digest,created=now(),seconds=time.perf_counter()-started,files={f.name:sha(f) for f in p.iterdir() if f.is_file() and f.name!='complete.json'}))
    print('E3_COMPLETE',c['case'],flush=True)
def select():
    digest=lock();dest=OUT/'selected';dest.mkdir(exist_ok=True)
    if verify_done(dest,digest):return
    allrows=[];choices=[];valrows=[];started=time.perf_counter()
    for H in [7,14]:
     for U in [28,56]:
      for fam in ['lgbm','mlp']:
       cs=[c for c in configs() if (c['H'],c['U'],c['family'])==(H,U,fam)];df=pd.concat([pd.read_parquet(OUT/'candidates'/c['case']/'daily.parquet') for c in cs])
       selected={}
       for length in [84,28]:
        for first in range(FIRST,LAST+1,56):
         hi=first-14;lo=hi-length+1
         for method in METHODS:
          for tau in TAUS:
           v=df[(df.method==method)&(df['quantile']==tau)&df.origin.between(lo,hi)];scores={}
           for param,part in v.groupby('parameter'):
            assert len(part)==length*3 and part.seed.nunique()==3
            denominator=part.n.sum();scores[param]=float(np.nansum(part.scaled_pinball*part.n)/denominator) if denominator else float('inf')
            valrows.append(dict(H=H,U=U,family=fam,length=length,selection_origin=first,validation_first=lo,validation_last=hi,last_maturity=hi+H,method=method,quantile=tau,parameter=param,loss=scores[param],n=int(denominator)))
           default=56. if method.startswith('WQ') else .1;param=choose(scores,default);selected[length,first,method,float(tau)]=param
           choices.append(dict(H=H,U=U,family=fam,length=length,selection_origin=first,method=method,quantile=tau,parameter=param))
       for c in cs:
        p=OUT/'candidates'/c['case'];z=load(p/'input.npz');mask=z['origins']>=FIRST
        for method in ['Raw','R2_reuse','R3_isolate']:
            f=df[(df.case==c['case'])&(df.method==method)&(df.origin>=FIRST)].copy();f['experiment']='bridge' if method!='Raw' else 'main';f['selection_length']=0;allrows.append(f)
        for length in [84,28]:
         for method in METHODS:
          q=ordered(z['base']);opened={}
          for first in range(FIRST,LAST+1,56):
           ix=(z['origins']>=first)&(z['origins']<first+56)
           for k,tau in enumerate(TAUS):
            param=selected[length,first,method,float(tau)]
            if param not in opened:opened[param]=np.load(p/f'{method}_p{param:g}.npy',mmap_mode='r')
            q[ix,:,k]=opened[param][ix,:,k]
          for suffix,qq in [('',q),('_sorted',np.sort(q,axis=-1))]:
            f=scoring(z,qq,method+suffix,c,mask);f['experiment']='E2' if length==84 else 'E1';f['selection_length']=length;allrows.append(f)
          np.save(dest/f'{c["case"]}_{method}_L{length}.npy',q[mask]);del opened
        print('SELECTED_REPLAY_COMPLETE',c['case'],flush=True)
    pd.concat(allrows).to_parquet(dest/'daily.parquet',index=False);csv(dest/'selections.csv',choices);csv(dest/'validation.csv',valrows)
    write(dest/'complete.json',dict(freeze_sha256=digest,created=now(),seconds=time.perf_counter()-started,files={f.name:sha(f) for f in dest.iterdir() if f.is_file() and f.name!='complete.json'}))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['run','select']);ap.add_argument('--family',choices=['lgbm','mlp']);a=ap.parse_args()
    if a.mode=='select':select()
    else:
        for c in configs():
            if a.family and c['family']!=a.family:continue
            candidates(c);e3(c)
