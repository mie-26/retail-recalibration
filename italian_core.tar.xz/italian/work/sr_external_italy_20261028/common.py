"""External Italian-store confirmation. A count origin t sees days [0,t)."""
import os,sys,json,hashlib,time,datetime
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
os.environ.setdefault('OMP_NUM_THREADS','4')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
for p in ['work/experiment_env/Lib/site-packages','work/transfer_env/Lib/site-packages']:
    sys.path.append(str(ROOT/p))
import numpy as np
import pandas as pd
OUT=ROOT/'outputs/sr_external_italy_20261028';OUT.mkdir(parents=True,exist_ok=True)
DATA=HERE/'data';TAUS=np.array([.9,.95]);SEEDS=[20261021,20261022,20261023]
DATES=pd.date_range('2014-01-01','2018-12-31');WARM=731;FIRST=1096;LAST=1812
def origin(date):return int((pd.Timestamp(date)-DATES[0]).days+1)
assert WARM==origin('2016-01-01') and FIRST==origin('2016-12-31') and LAST==origin('2018-12-17')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def write(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=lambda a:a.item() if isinstance(a,np.generic) else str(a)),encoding='utf8');tmp.replace(p)
def csv(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);pd.DataFrame(x).to_csv(p,index=False,encoding='utf-8-sig')
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def lock():
    p=OUT/'freeze_manifest.json';f=read(p);assert f['status']=='FROZEN'
    for name,h in f['code_sha256'].items():assert sha(HERE/name)==h,('frozen code differs',name)
    assert sha(DATA/'hierarchical_sales_data.csv')==f['data_sha256']
    for name,h in f['selection_sha256'].items():assert sha(OUT/name)==h
    return sha(p)
def target(y,oo,H):return np.array([np.sum(y[:,int(t):int(t)+H],axis=1) for t in oo])
def ordered(q):return np.sort(np.maximum(q,0),axis=-1)
def cuts(U=28):return np.arange(WARM,LAST+1,U)
def config_name(H,U,family,seed):return f'h{H}_u{U}_{family}_s{seed}'
def configs():
    return [dict(H=H,U=U,family=f,seed=s,case=config_name(H,U,f,s)) for H in [7,14] for U in [28,56] for f in ['lgbm','mlp'] for s in SEEDS]
