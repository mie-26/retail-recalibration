from common import *

def labels_for(groups,sharing):
    if sharing=='series':return np.arange(len(groups))
    if sharing=='global':return np.zeros(len(groups),int)
    if sharing=='group':return np.unique(groups,return_inverse=True)[1]
    raise ValueError(sharing)
def weighted_inverse(v,w,tau):
    ok=np.isfinite(v)&(w>0);v=v[ok];w=w[ok]
    if not len(v):return 0.
    ix=np.argsort(v,kind='stable');v=v[ix];w=w[ix]
    return float(v[min(len(v)-1,np.searchsorted(np.cumsum(w),tau*w.sum(),side='left'))])
def replay_control(z,H,rule,sharing,param):
    """Calendar-window WQ or constant-step QT; equal mass per mature date."""
    start=time.perf_counter();b=ordered(z['base'].astype(float));y=z['truth'];sc=z['scale'];oo=z['origins'];vv=z['versions']
    T,N,K=b.shape;q=np.empty_like(b);labels=labels_for(z['groups'],sharing);G=int(labels.max())+1
    theta=np.zeros((G,K));res=(y[:,:,None]-b)/sc[None,:,None];logs=[]
    gm=[np.flatnonzero(labels==g) for g in range(G)] if sharing!='series' else None
    seen=np.zeros(N,bool);released_count=0;released_dates=0;last_consumed=-1
    for t,o in enumerate(oo):
        # Right inclusive mature boundary; processing occurs before current issue.
        mature=np.flatnonzero(oo+H<=o)
        if rule=='QT':
            for s in mature[mature>last_consumed]:
                valid=np.isfinite(y[s]);seen|=valid;released_count+=int(valid.sum());released_dates+=1
                feedback=TAUS-(y[s,:,None]<=q[s])
                if sharing=='series':theta[valid]+=float(param)*feedback[valid]
                else:
                    count=np.bincount(labels[valid],minlength=G)
                    for k in range(2):
                        total=np.bincount(labels[valid],weights=feedback[valid,k],minlength=G)
                        theta[:,k]+=float(param)*np.divide(total,count,out=np.zeros(G),where=count>0)
                last_consumed=int(s)
            q[t]=np.maximum(b[t]+theta[labels]*sc[:,None],0)
            ix=mature;active=int(seen.sum()) if sharing=='series' else sum(int((labels==g).sum()) for g in range(G) if seen[labels==g].any())
            nr=released_count
        else:
            assert rule=='WQ';ix=mature[oo[mature]>=o-int(param)]
            offset=np.zeros((N,2));valid=np.isfinite(y[ix]);nr=int(valid.sum());active=0
            if len(ix):
                if sharing=='series':
                    count=valid.sum(0);active=int((count>0).sum());a=np.sort(np.where(np.isfinite(res[ix]),res[ix],np.inf),axis=0)
                    for k,tau in enumerate(TAUS):
                        pos=np.maximum(0,np.ceil(tau*count).astype(int)-1)
                        offset[:,k]=np.where(count>0,a[pos,np.arange(N),k],0)
                else:
                    for members in gm:
                        rr=res[ix][:,members];count=np.isfinite(rr[:,:,0]).sum(1)
                        w=np.broadcast_to(np.divide(1.,count,out=np.zeros(len(ix)),where=count>0)[:,None],rr.shape[:2]).ravel()
                        if count.sum():active+=len(members)
                        for k,tau in enumerate(TAUS):offset[members,k]=weighted_inverse(rr[:,:,k].ravel(),w,tau)
            q[t]=np.maximum(b[t]+offset*sc[:,None],0)
        logs.append(dict(origin=int(o),method=f'{rule}_{sharing}',parameter=float(param),eligible_origins=len(ix),valid_residual_targets=nr,active_series=active,states=G,old_origins=int((vv[ix]!=vv[t]).sum()),latest_maturity=int(oo[ix[-1]]+H) if len(ix) else -1,fallback_all=active==0))
    assert np.isfinite(q).all() and (q>=0).all()
    return q,logs,time.perf_counter()-start
def choose(scores,default):
    return sorted(scores,key=lambda p:(scores[p],p!=default,p))[0]


def pair_predictions(y,old,new,sc,groups,oo,H,window):
    """Matched post-switch references; both arms calibrate the same new baseline."""
    b=ordered(new.astype(float));refs=[ordered(old.astype(float)),b];outputs=[b.copy(),b.copy()];logs=[]
    for ai,reference in enumerate(refs):
        res=(y[:,:,None]-reference)/sc[None,:,None]
        for t,o in enumerate(oo):
            ix=np.flatnonzero((oo+H<=o)&(oo>=o-window));pre=b[t].copy();active=0;nr=int(np.isfinite(y[ix]).sum())
            for g in np.unique(groups):
                take=groups==g;rr=res[ix][:,take]
                if len(ix) and np.isfinite(rr).any():
                    active+=int(take.sum())
                    for k,tau in enumerate(TAUS):
                        v=rr[:,:,k].ravel();v=v[np.isfinite(v)]
                        if len(v):pre[take,k]+=float(np.quantile(v,tau,method='higher'))*sc[take]
            outputs[ai][t]=ordered(pre)
            logs.append(dict(origin=int(o),arm='old_reference' if ai==0 else 'new_reference',eligible_origins=len(ix),valid_residual_targets=nr,active_series=active,latest_maturity=int(oo[ix[-1]]+H) if len(ix) else -1,fallback_all=active==0))
    return outputs,logs
