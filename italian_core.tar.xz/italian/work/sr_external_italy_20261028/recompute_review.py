"""Fast review: recompute every selected scalar score and co-primary block interval."""
from common import *
def aggregate(df,keys):
    rows=[]
    for key,g in df.groupby(keys,dropna=False):
        r=dict(zip(keys,key));den=float(g.n.sum())
        for name in ['scaled_pinball','pinball','weak','strict','equality','zero_tie']:
            r[name]=float(g[name].fillna(0).dot(g.n)/den) if den else np.nan
        rows.append(r)
    return pd.DataFrame(rows)
def streams(df,methods):
    out={};count=None
    for m in methods:
        f=df[df.method==m].copy();f['numerator']=f.scaled_pinball.fillna(0)*f.n
        f=f.groupby('origin')[['numerator','n']].sum().reindex(range(FIRST,LAST+1),fill_value=0)/len(SEEDS)
        out[m]=f.numerator.to_numpy();n=f.n.to_numpy()
        if count is not None:np.testing.assert_array_equal(n,count)
        count=n
    return out,count
def blockweights(T,block):
    rng=np.random.default_rng(20261028+block);starts=rng.integers(T,size=(5000,int(np.ceil(T/block))))
    indexes=((starts[:,:,None]+np.arange(block))%T).reshape(5000,-1)[:,:T]
    return np.array([np.bincount(x,minlength=T) for x in indexes],dtype=float)
def main():
    lock();p=OUT/'analysis';df=pd.read_parquet(OUT/'selected/daily.parquet');keys=['H','U','family','experiment','selection_length','method','quantile']
    got=aggregate(df,keys).sort_values(keys).reset_index(drop=True);expected=pd.read_csv(p/'scores.csv').sort_values(keys).reset_index(drop=True)
    cols=['scaled_pinball','pinball','weak','strict','equality','zero_tie'];error=float(np.nanmax(np.abs(got[cols].to_numpy()-expected[cols].to_numpy())));np.testing.assert_allclose(got[cols],expected[cols],rtol=1e-10,atol=1e-12,equal_nan=True)
    res=[]
    for tau in TAUS:
        g=df[(df.H==14)&(df.U==28)&(df.family=='lgbm')&(df['quantile']==tau)&((df.selection_length==84)|(df.method=='Raw'))]
        nums,n=streams(g,['Raw','QT_group','QT_series','WQ_group','WQ_series']);w=blockweights(len(n),28);den=w@n;v={k:(w@a)/den for k,a in nums.items()}
        b=100*((v['QT_group']-v['QT_series'])-(v['WQ_group']-v['WQ_series']))/v['Raw'];ci=np.quantile(b,[.0125,.9875])
        ref=pd.read_csv(p/'interaction_intervals.csv');r=ref[(ref.H==14)&(ref.U==28)&(ref.family=='lgbm')&(ref['quantile']==tau)&(ref.block==28)].iloc[0]
        np.testing.assert_allclose(ci,[r.lower97_5,r.upper97_5],rtol=1e-10,atol=1e-10);res.append(dict(quantile=tau,interval=ci.tolist()))
    write(OUT/'quick_recompute.json',dict(created=now(),passed=True,rows=len(got),max_score_error=error,primary_intervals=res));print('QUICK_RECOMPUTE_PASS',len(got),'score rows; primary intervals match')
if __name__=='__main__':main()
