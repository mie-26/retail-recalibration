"""Release-layer score audit for the unchanged Windows-origin frozen Italian experiment.

Path normalization changes only how manifest-relative filenames are resolved.
The original scientific files and freeze manifest must still hash exactly.
No fitting, parameter selection, or scientific estimator is changed here.
"""
from pathlib import Path,PurePosixPath
import sys,runpy
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import common
def manifest_path(root,name):
    p=PurePosixPath(str(name).replace('\\','/'))
    if p.is_absolute() or '..' in p.parts or any(':' in x for x in p.parts):raise ValueError('Unsafe manifest path')
    return root.joinpath(*p.parts)
def portable_lock():
    p=common.OUT/'freeze_manifest.json';f=common.read(p);assert f['status']=='FROZEN'
    for name,h in f['code_sha256'].items():assert common.sha(manifest_path(HERE,name))==h,name
    assert common.sha(common.DATA/'hierarchical_sales_data.csv')==f['data_sha256']
    for name,h in f['selection_sha256'].items():assert common.sha(manifest_path(common.OUT,name))==h,name
    return common.sha(p)
def main():
    assert PurePosixPath('selection/h7_lgbm/selected.json').parts==PurePosixPath('selection\\h7_lgbm\\selected.json'.replace('\\','/')).parts
    common.lock=portable_lock
    original_write=common.write
    def release_write(path,value):
        if Path(path)!=(common.OUT/'quick_recompute.json'):
            raise ValueError('Unexpected audit write destination')
        original_write(common.OUT/'release_audit/quick_recompute.json',value)
    common.write=release_write
    runpy.run_path(str(HERE/'recompute_review.py'),run_name='__main__')
if __name__=='__main__':main()
