"""Before freeze, parse numbers ONLY in 2014-2015; dates/headers may span all rows."""
from common import *
import csv as csvlib,zipfile
def parse(early=True):
    if not early:lock()
    with (DATA/'hierarchical_sales_data.csv').open(encoding='utf-8-sig',newline='') as f:
        rr=csvlib.DictReader(f);names=[c for c in rr.fieldnames if c.startswith('QTY_')]
        y=np.full((len(names),len(DATES)),np.nan);dates=[];skipped=0
        for r in rr:
            d=pd.Timestamp(r['DATE']);i=int((d-DATES[0]).days);dates.append(d)
            assert 0<=i<len(DATES)
            if early and d>pd.Timestamp('2015-12-31'):skipped+=1;continue
            a=np.array([float(r[n]) if r[n] not in ['', 'NA','NaN'] else np.nan for n in names])
            assert not (a[np.isfinite(a)]<0).any();y[:,i]=a
    assert len(set(dates))==len(dates),'duplicate dates require pre-analysis resolution'
    return y,names,pd.DatetimeIndex(dates),skipped
def audit():
    assert not (OUT/'protected_access.json').exists()
    z2=Path('C:/Users/lenovo/Downloads/Data for A machine learning approach for forecasting hierarchical time series.zip')
    with zipfile.ZipFile(z2) as z:
        assert z.testzip() is None;b=z.read(next(n for n in z.namelist() if n.endswith('.csv')))
        comparison=hashlib.sha256(b).hexdigest()
    y,names,dd,skipped=parse();hist=y[:,:origin('2015-12-31')];n=np.isfinite(hist).sum(1);pos=(hist>0).sum(1)
    freq=pos/np.maximum(n,1);eligible=(n>=180)&(pos>=20);group=np.where(freq<.2,0,np.where(freq<.5,1,2))
    rows=[dict(sku=name,brand=name.split('_')[1],valid_days=int(n[i]),positive_days=int(pos[i]),frequency=float(freq[i]),group=int(group[i]),eligible=bool(eligible[i]),reason='' if eligible[i] else 'fewer than180 observed or20 positive early days') for i,name in enumerate(names)]
    csv(OUT/'cohort_all.csv',rows);csv(OUT/'cohort.csv',[r for r in rows if r['eligible']]);np.save(OUT/'early_panel.npy',y[eligible])
    missing=DATES.difference(dd);csv(OUT/'calendar_audit.csv',[dict(date=str(d.date()),observed=bool(d in dd)) for d in DATES])
    result=dict(created=now(),source='https://data.mendeley.com/datasets/s8dgbs3rng/1',related='https://data.mendeley.com/datasets/njdkntcpc9/1',license='CC BY-NC 3.0',raw_sha256=sha(DATA/'hierarchical_sales_data.csv'),related_csv_sha256=comparison,identical_csv_versions=comparison==sha(DATA/'hierarchical_sales_data.csv'),rows=len(dd),calendar_days=len(DATES),missing_dates=[str(d.date()) for d in missing],skus=len(names),eligible_skus=int(eligible.sum()),early_group_counts=pd.Series(group[eligible]).value_counts().sort_index().to_dict(),numerical_values_read_through='2015-12-31',later_rows_skipped_before_numeric_conversion=skipped)
    write(OUT/'admission.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
def unlock():
    digest=lock();p=OUT/'protected_access.json'
    if not p.exists():write(p,dict(first_numeric_access_at=now(),freeze_sha256=digest,scope='2016 warmup and 2017-2018 protected targets; frozen automated run'))
    y,names,_,_=parse(False);keep=pd.read_csv(OUT/'cohort.csv').sku.tolist();y=y[[names.index(n) for n in keep]]
    np.save(OUT/'full_panel.npy',y)
if __name__=='__main__':audit() if len(sys.argv)<2 or sys.argv[1]=='audit' else unlock()
