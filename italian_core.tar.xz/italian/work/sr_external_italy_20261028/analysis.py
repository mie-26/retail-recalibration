"""Calendar block intervals conditional on frozen fitted and selected paths."""
from common import *
from replay import METRICS,METHODS
def aggregate(df,keys):
    rows=[]
    for key,g in df.groupby(keys,dropna=False):
        if not isinstance(key,tuple):key=(key,)
        n=g.n.sum();r=dict(zip(keys,key));r['n_across_seeds']=int(n);r['effective_pairs_per_seed']=float(n/g.seed.nunique())
        for m in METRICS:r[m]=float(np.nansum(g[m]*g.n)/n) if n else np.nan
        rows.append(r)
    return pd.DataFrame(rows)
def blockweights(T,block,B=5000):
    rng=np.random.default_rng(20261028+block);starts=rng.integers(T,size=(B,int(np.ceil(T/block))));ix=((starts[:,:,None]+np.arange(block))%T).reshape(B,-1)[:,:T]
    w=np.zeros((B,T),np.float64)
    for i in range(B):w[i]=np.bincount(ix[i],minlength=T)
    return w
def streams(df,methods):
    # Average seed losses, retaining each natural calendar day, even count=0.
    oo=np.arange(FIRST,LAST+1);out={};count=None
    for m in methods:
        p=df[df.method==m].copy();p['sum']=np.nan_to_num(p.scaled_pinball)*p.n
        g=p.groupby('origin').agg(total=('sum','sum'),n=('n','sum')).reindex(oo,fill_value=0)
        n=g.n.to_numpy()/3.;num=g.total.to_numpy()/3
        if count is None:count=n
        else:np.testing.assert_array_equal(count,n)
        out[m]=num
    return out,count
def run():
    digest=lock();dest=OUT/'analysis';dest.mkdir(exist_ok=True);start=time.perf_counter()
    df=pd.read_parquet(OUT/'selected/daily.parquet');keys=['H','U','family','experiment','selection_length','method','quantile']
    aggregate(df,keys).to_csv(dest/'scores.csv',index=False)
    aggregate(df,keys+['seed']).to_csv(dest/'seed_scores.csv',index=False)
    df['year']=pd.to_datetime(df.date).dt.year;aggregate(df,keys+['year']).to_csv(dest/'year_scores.csv',index=False)
    e3=pd.concat([pd.read_parquet(OUT/'e3'/c['case']/'daily.parquet') for c in configs()]);aggregate(e3,['H','U','family','method','quantile']).to_csv(dest/'E3_scores.csv',index=False)
    aggregate(e3,['H','U','family','method','quantile','phase']).to_csv(dest/'E3_phase_scores.csv',index=False)
    fixed=pd.concat([pd.read_parquet(OUT/'candidates'/c['case']/'daily.parquet') for c in configs()]);fixed=fixed[fixed.origin>=FIRST]
    aggregate(fixed,['H','U','family','method','parameter','quantile']).to_csv(dest/'fixed_grid_scores.csv',index=False)
    rows=[];effects=[];nonover=[];primary=[]
    for (H,U,fam,tau),g in df.groupby(['H','U','family','quantile']):
      main=g[(g.selection_length==84)|g.method.isin(['Raw','R2_reuse','R3_isolate'])]
      arms=['Raw','QT_group','QT_series','WQ_group','WQ_series','R2_reuse','R3_isolate']
      nums,n=streams(main,arms);means={m:v.sum()/n.sum() for m,v in nums.items()}
      interaction=100*((means['QT_group']-means['QT_series'])-(means['WQ_group']-means['WQ_series']))/means['Raw']
      for block in sorted(set([H,2*H,4*H,56])):
        w=blockweights(len(n),int(block));den=w@n;loss={m:np.divide(w@v,den,out=np.full(len(w),np.nan),where=den>0) for m,v in nums.items()}
        boot=100*((loss['QT_group']-loss['QT_series'])-(loss['WQ_group']-loss['WQ_series']))/loss['Raw']
        q=np.nanquantile(boot,[.0125,.025,.975,.9875]);r=dict(H=H,U=U,family=fam,quantile=tau,block=int(block),main_block=bool(block==2*H),replicates=5000,interaction_percent=interaction,lower97_5=q[0],lower95=q[1],upper95=q[2],upper97_5=q[3]);rows.append(r)
        if H==14 and U==28 and fam=='lgbm' and block==28:primary.append(r)
        for candidate,reference in [('QT_group','QT_series'),('WQ_group','WQ_series'),('WQ_group','Raw'),('QT_group','Raw'),('R2_reuse','Raw'),('R3_isolate','Raw'),('R2_reuse','R3_isolate')]:
            b=100*(loss[candidate]/loss[reference]-1);lo,hi=np.nanquantile(b,[.025,.975]);effects.append(dict(H=H,U=U,family=fam,quantile=tau,block=int(block),candidate=candidate,reference=reference,relative_loss_percent=100*(means[candidate]/means[reference]-1),lower95=lo,upper95=hi))
      for offset in range(int(H)):
        ix=np.arange(offset,len(n),int(H));mm={m:v[ix].sum()/n[ix].sum() for m,v in nums.items()};nonover.append(dict(H=H,U=U,family=fam,quantile=tau,offset=offset,n=float(n[ix].sum()),interaction_percent=100*((mm['QT_group']-mm['QT_series'])-(mm['WQ_group']-mm['WQ_series']))/mm['Raw']))
      print('STATISTICS_COMPLETE',H,U,fam,tau,flush=True)
    csv(dest/'interaction_intervals.csv',rows);csv(dest/'effect_intervals.csv',effects);csv(dest/'nonoverlap_interactions.csv',nonover)
    # E3 paired contrasts use the identical calendar bootstrap; descriptive secondary intervals.
    erows=[]
    for (H,U,fam,tau),g in e3.groupby(['H','U','family','quantile']):
      nums,n=streams(g,['Raw','old_reference','new_reference']);w=blockweights(len(n),int(2*H));den=w@n;vals={m:(w@v)/den for m,v in nums.items()}
      for cand,ref in [('new_reference','old_reference'),('new_reference','Raw'),('old_reference','Raw')]:
        b=100*(vals[cand]/vals[ref]-1);lo,hi=np.quantile(b,[.025,.975]);erows.append(dict(H=H,U=U,family=fam,quantile=tau,candidate=cand,reference=ref,block=int(2*H),relative_loss_percent=100*(nums[cand].sum()/nums[ref].sum()-1),lower95=lo,upper95=hi))
    csv(dest/'E3_intervals.csv',erows)
    costs=[]
    for p in (OUT/'bank').glob('*/*/complete.json'):
        m=read(p);costs.append({k:m[k] for k in ['H','family','seed','cutoff','fit_seconds','inference_seconds','base_model_count']})
    csv(dest/'fit_costs.csv',costs)
    feedback=[]
    for c in configs():
      p=OUT/'candidates'/c['case'];f=pd.read_parquet(p/'feedback.parquet');f=f[(f.origin>=FIRST)&f.method.isin(['R2_reuse','R3_isolate'])]
      for m,g in f.groupby('method'):feedback.append(dict(**c,method=m,fallback_days=int(g.fallback_all.sum()),days=len(g),mean_valid_residual_targets=float(g.valid_residual_targets.mean()),median_active_series=float(g.active_series.median())))
    csv(dest/'feedback_availability.csv',feedback)
    result='full_directional_support' if all(r['lower97_5']>0 for r in primary) else ('opposite_direction_evidence' if any(r['upper97_5']<0 for r in primary) else ('partial_directional_support' if any(r['lower97_5']>0 for r in primary) else 'inconclusive'))
    assert len(primary)==2 and len(costs)==468 and sum(r['base_model_count'] for r in costs)==702
    write(dest/'decision.json',dict(created=now(),primary=primary,result=result,warning='Conditional calendar-block intervals; one store and one category. No universal causal or coverage guarantee.',base_models=702,fit_jobs=468,measured_fit_seconds=sum(r['fit_seconds'] for r in costs)))
    write(dest/'complete.json',dict(created=now(),freeze_sha256=digest,seconds=time.perf_counter()-start,files={p.name:sha(p) for p in dest.iterdir() if p.is_file() and p.name!='complete.json'}))
if __name__=='__main__':run()
