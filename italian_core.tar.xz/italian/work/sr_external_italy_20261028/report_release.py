"""Reporting/packaging added after execution; does not change frozen estimators."""
from common import *
import shutil,zipfile,html
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def main():
    lock();assert read(OUT/'verification.json')['all_passed'];assert read(OUT/'quick_recompute.json')['passed']
    a=OUT/'analysis';fig=OUT/'figures';fig.mkdir(exist_ok=True)
    scores=pd.read_csv(a/'scores.csv');intervals=pd.read_csv(a/'interaction_intervals.csv');effects=pd.read_csv(a/'effect_intervals.csv');decision=read(a/'decision.json')
    configs8=[(H,U,f) for f in ['lgbm','mlp'] for H in [7,14] for U in [28,56]];labels=[f'{f.upper()}  H{H} / U{U}' for H,U,f in configs8]
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
    def save(name,f):
        f.savefig(fig/(name+'.pdf'),bbox_inches='tight');f.savefig(fig/(name+'.svg'),bbox_inches='tight');f.savefig(fig/(name+'.png'),dpi=220,bbox_inches='tight');plt.close(f)
    f,axs=plt.subplots(1,2,figsize=(10,4.8),sharey=True)
    for tau,ax in zip(TAUS,axs):
        g=intervals[(intervals['quantile']==tau)&intervals.main_block]
        for j,(H,U,fam) in enumerate(configs8):
            r=g[(g.H==H)&(g.U==U)&(g.family==fam)].iloc[0];primary=(H,U,fam)==(14,28,'lgbm');lo=r.lower97_5 if primary else r.lower95;hi=r.upper97_5 if primary else r.upper95
            ax.errorbar(r.interaction_percent,j,xerr=[[r.interaction_percent-lo],[hi-r.interaction_percent]],fmt='s' if primary else 'o',color='#174d72' if primary else '#8796a5',capsize=3,markersize=6)
        ax.axvline(0,color='.35',lw=.8);ax.set_title(f'q{int(tau*100)}');ax.set_xlabel('Rule × sharing interaction (% of Raw loss)');ax.grid(axis='x',alpha=.15)
    axs[0].set_yticks(range(8),labels);axs[0].invert_yaxis();f.suptitle('External confirmation in one Italian grocery store',fontsize=13)
    f.text(.25,-.02,'Dark square: prespecified primary, 97.5% CI. Other intervals: descriptive 95% CI.\nCalendar blocks = 2H; 5,000 paired resamples; positive interaction does not imply superiority to Raw.',fontsize=9)
    f.tight_layout();save('01_rule_sharing_interaction',f)
    bridge=[]
    for H,U,fam in configs8:
        g=scores[(scores.H==H)&(scores.U==U)&(scores.family==fam)]
        raw=g[g.method=='Raw'].sort_values('quantile')
        for m in ['R2_reuse','R3_isolate']:
            p=g[g.method==m].sort_values('quantile');bridge.append(dict(H=H,U=U,family=fam,method=m,joint_scaled_pinball=p.scaled_pinball.mean(),joint_loss_change_percent=100*(p.scaled_pinball.mean()/raw.scaled_pinball.mean()-1),q90_weak=p.weak.iloc[0],q95_weak=p.weak.iloc[1],q90_weak_change_pp=100*(p.weak.iloc[0]-raw.weak.iloc[0]),q95_weak_change_pp=100*(p.weak.iloc[1]-raw.weak.iloc[1])))
    bridge=pd.DataFrame(bridge);bridge.to_csv(a/'bridge_joint_summary.csv',index=False)
    f,axs=plt.subplots(1,3,figsize=(12,5),sharey=True)
    for m,color,label,shift in [('R2_reuse','#146a80','Reuse',-.12),('R3_isolate','#bb6645','Isolate',.12)]:
        g=bridge[bridge.method==m]
        for ax,col in zip(axs,['joint_loss_change_percent','q90_weak_change_pp','q95_weak_change_pp']):
            ax.plot(g[col],np.arange(8)+shift,'o',color=color,label=label,markersize=5)
    for ax,title in zip(axs,['Joint loss change vs Raw (%)','q90 weak coverage change (pp)','q95 weak coverage change (pp)']):
        ax.axvline(0,color='.4',lw=.8);ax.set_title(title,fontsize=10);ax.grid(axis='x',alpha=.15)
    axs[0].set_yticks(range(8),labels);axs[0].invert_yaxis();axs[-1].legend(frameon=False,loc='lower right');f.suptitle('A fixed calibrator: feedback reuse and isolation',fontsize=13)
    f.text(.2,-.02,'Point estimates, equal quantile joint loss. Negative loss change is better.\nAll per-quantile paired intervals, including intervals crossing zero, are supplied in effect_intervals.csv.',fontsize=9);f.tight_layout();save('02_feedback_reuse_tradeoffs',f)
    # Prespecified E1 sensitivity: univariate paths and post-hoc sorted paths both retained.
    short=scores[scores.selection_length==28];long=scores[scores.selection_length==84]
    e1=short.merge(long,on=['H','U','family','method','quantile'],suffixes=('_short','_long'));e1['long_history_loss_change_percent']=100*(e1.scaled_pinball_long/e1.scaled_pinball_short-1);e1.to_csv(a/'E1_history_sensitivity.csv',index=False)
    # Same estimands, predeclared origin-year summaries; 2016 has zero valid targets.
    years=pd.read_csv(a/'year_scores.csv');yr=[]
    for (H,U,fam,tau,year),g in years.groupby(['H','U','family','quantile','year']):
        if year not in [2017,2018]:continue
        main=g[(g.selection_length==84)|(g.method=='Raw')].set_index('method')
        v=main.scaled_pinball
        yr.append(dict(H=H,U=U,family=fam,quantile=tau,year=year,interaction_percent=100*((v['QT_group']-v['QT_series'])-(v['WQ_group']-v['WQ_series']))/v['Raw']))
    csv(a/'year_interactions.csv',yr)
    cost=[]
    cost.append(dict(component='base_model_training',seconds=decision['measured_fit_seconds'],type='sum of measured fitter wall times; concurrent jobs overlap'))
    fit=pd.read_csv(a/'fit_costs.csv');cost.append(dict(component='base_and_shadow_inference',seconds=fit.inference_seconds.sum(),type='sum measured; includes E3 shadow predictions'))
    early=sum(read(p)['fit_seconds'] for p in (OUT/'selection').glob('*/selected.json'));cost.append(dict(component='early_hyperparameter_search',seconds=early,type='measured separately, before freeze'))
    cc=[]
    for p in (OUT/'candidates').glob('*/costs.csv'):
        g=pd.read_csv(p);cc.extend(g.to_dict('records'))
    cost.append(dict(component='all_background_calibration_kernels',seconds=sum(r['seconds'] for r in cc),type='measured candidate computation, not deployed-only expense'))
    cost.append(dict(component='selected_path_promotion_and_scoring',seconds=read(OUT/'selected/complete.json')['seconds'],type='measured'))
    cost.append(dict(component='statistical_analysis',seconds=read(a/'complete.json')['seconds'],type='measured'))
    cost.append(dict(component='whole_frozen_pipeline_wall',seconds=read(OUT/'run_complete.json')['wall_seconds'],type='actual elapsed; excludes download, early selection and later audit/report'))
    csv(a/'cost_accounting.csv',cost)
    logical=[]
    for c in configs():logical.append(dict(**c,whole_trace_model_uses=len(cuts(c['U']))*(2 if c['family']=='lgbm' else 1),confirmation_updates=int((cuts(c['U'])>=FIRST).sum()),unique_bank_shared_between_U=True))
    csv(a/'logical_deployment_cost.csv',logical)
    primary=scores[(scores.H==14)&(scores.U==28)&(scores.family=='lgbm')&scores.method.isin(['Raw','QT_series','QT_group','WQ_series','WQ_group'])&((scores.selection_length==84)|(scores.method=='Raw'))][['method','quantile','scaled_pinball','weak','strict','effective_pairs_per_seed']]
    primary.to_csv(a/'primary_arm_scores.csv',index=False)
    def table(df):return df.to_html(index=False,float_format=lambda x:f'{x:.4f}',border=0)
    report='''<!doctype html><html lang="zh"><meta charset="utf-8"><title>意大利新来源确认实验报告</title><style>body{max-width:1050px;margin:48px auto;font:16px/1.8 "Microsoft YaHei",Arial;color:#20303e;padding:0 24px}h1,h2{line-height:1.35;color:#173d56}table{border-collapse:collapse;width:100%;font-size:13px;margin:20px 0;border-top:2px solid;border-bottom:2px solid}thead{border-bottom:1px solid}th,td{padding:6px;text-align:right}th:first-child,td:first-child{text-align:left}img{width:100%}.box{background:#edf3f6;padding:18px 24px}code{font-size:13px}a{color:#176a8b}</style><h1>意大利新来源外部确认：实验完成报告</h1><p>2026-10-28 · Scientific Reports 论文补强 · 新来源、单门店、单品类</p>
<div class="box"><b>结论：主要交互假设获得支持，但校准的实际收益仍然依赖基础模型。</b>固定反馈复用在 LightGBM 上降低联合损失，在 MLP 上增加联合损失。新版本残差相对旧版本残差的额外优势仍不明确。本轮增强的是方法依赖和维护权衡的实证证据，不构成新算法全面领先的证明。</div>
<h2>1. 数据与冻结边界</h2><p>已从作者 Mendeley 两个官方发布记录下载 CSV，两版本 SHA256 完全相同。118 个 SKU 全部通过仅基于2014–2015年的资格筛选。原表1798行；自然日历1826天，28个缺失日保持NA，未按节假日推定为零。频率组为中频10、高频108，没有低频组。该数据来自一家意大利杂货店的意面商品，不能代表多行业、多门店独立重复。</p>
<p>2014–2015用于历史模型选参；2016用于实际候选预测热启动。模型和统计协议在2017–2018数值首次读取之前冻结。717个共同日历原点中，H7有647个有效原点（76,346个SKU–原点对/种子），H14有584个（68,912对/种子）。所有方法使用相同目标掩码；自举保留缺失日历位置。</p>
<p>冻结：2026-10-28 11:26:45.921589 UTC；确认数值首次读取：11:26:47.043311 UTC。冻结哈希：<code>3749d12b1cfc4e2fd3e81deea440f80f10db983d2c930097f82ea47a1a89c3f5</code>。</p>
<h2>2. 主要检验：校准规则 × 信息共享</h2><p>预先指定 LightGBM、H14、U28，q90/q95为两个共同主要端点；主块长28天，5000次配对日历块重采样。交互为100×[(QT分组−QT逐序列)−(WQ分组−WQ逐序列)]/Raw。两项97.5%区间下限均大于零，满足冻结的同方向支持标准。下列百分数是交互效应以Raw损失归一化的量，<b>不是新方法相对Raw的损失下降百分比</b>。</p>'''
    report+=table(pd.DataFrame(decision['primary'])[['quantile','interaction_percent','lower97_5','upper97_5']])
    report+='<p>全部16个模型/跨度/日历/分位组合的主块长区间同方向；全部56个预设块长结果的97.5%区间也高于零。这些组合共享同一来源，不是16个独立数据集。完整四臂和Raw评分如下，包含逐序列WQ较明显的覆盖不足，不能只展示交互系数。</p>'+table(primary)+'<img src="figures/01_rule_sharing_interaction.png">'
    report+='''<h2>3. 固定滚动校准器：反馈复用与版本隔离</h2><p>本对照沿用论文原始56天分组滚动校准器、higher经验分位数和非负排序；复用与隔离仅改变版本筛选，均使用同一模型银行与更新日历。它与E2的等原点质量WQ不是同一估计器，不能混称。</p><p>复用旧反馈相对Raw：LightGBM四种设置联合损失下降0.862%–1.348%，MLP则增加0.740%–2.122%。复用相对隔离的联合损失点估计在8/8设置较低，但单分位区间存在跨零；本结果不证明无条件复用最优。版本隔离在8/8设置中的联合损失点估计均高于Raw。</p>'''
    report+=table(bridge[['H','U','family','method','joint_loss_change_percent','q90_weak_change_pp','q95_weak_change_pp']])+'<img src="figures/02_feedback_reuse_tradeoffs.png">'
    report+='''<p>版本隔离的Raw回退天数（717个日历原点）为：H7/U28=202，H7/U56=110，H14/U28=397，H14/U56=205；反馈复用均为0。这里包含因源数据缺失导致成熟目标不可用的额外等待，不能把全部回退归因于理论H天延迟。</p>
<h2>4. E3与E1：保留不明确的结果</h2><p>E3比较同原点、同目标的新旧模型残差，两个校准臂使用相同的新模型预测与相同有效样本。16个“新参考−旧参考”单分位损失差区间全部跨零；这表示额外优势未获明确支持，不能解释为两者严格等价。全周期和版本年龄分层均保留在补充表中。</p><p>E1的28天/84天历史选择敏感性、全部固定参数网格、逐种子、逐年和全部H个非重叠偏移均已输出。没有依据结果返回扩大网格或更换主要任务。</p>
<h2>5. 计算与核验</h2><p>实际执行468个拟合作业：468个LightGBM单分位模型和234个双分位MLP，共702个基础模型（不含早期超参数搜索）。U56共享U28的相同训练截点。逻辑部署模型使用数与实际唯一拟合数分开记录；影子预测和候选后台成本也计入。</p>'''+table(pd.DataFrame(cost))
    report+='''<p>冻结前14项测试通过；全部468个拟合记录、模型文件哈希及训练截止检查通过；8个代表拟合作业重新加载模型并推理；24个案例的候选状态晋升与掩码核验通过；432行最终评分与两个共同主要区间复算通过。这里的复算在本地同一环境完成，不冒充外部第三方复现。</p>
<h2>6. 论文可以怎样使用</h2><p>建议将本轮作为“新来源的冻结确认”纳入补充材料，正文保留一张交互效应图和一张同条件反馈对照表。主张应聚焦：共享收益与校准递推规则存在交互；相同的反馈复用校准器，在不同基础模型下可能改善或损害预测损失；新版本残差的额外优势并未得到一致证实。</p><p>避免宣称普遍最优维护策略、行业级泛化、严格覆盖保证，或将15%–20%的交互数值写成整体算法提升。统计区间条件于已拟合/已选择的预测路径，未覆盖重新训练和重新选参的不确定性。</p>
<h2>7. 文件与复现</h2><p>本包包含新实验代码、原始CSV及来源许可说明、冻结协议、历史选参记录、逐日主评分、全部固定候选评分、反馈日志、关键表图、核验结果和快速复算脚本。没有加入历史版本材料或稿件本身。完整模型权重与逐商品候选数组约1.9GiB保存在本机实验目录；轻量包不含这些大文件，完整重训需本机安装依赖并运行run_all.py。</p><p>快速复算：<code>python work/sr_external_italy_20261028/recompute_review.py</code>。完整重建在独立副本中执行：<code>python work/sr_external_italy_20261028/run_all.py</code>，会重建模型库与候选数组。不得重新按确认期成绩选择参数。详见根目录README.txt。</p>
<p>数据来源：<a href="https://data.mendeley.com/datasets/s8dgbs3rng/1">作者数据记录</a>；<a href="https://data.mendeley.com/datasets/njdkntcpc9/1">论文关联记录</a>。按实际获取记录保留CC BY-NC 3.0说明；两个记录为同一数据，未合并成两个来源。</p></html>'''
    (OUT/'REPORT.html').write_text(report,encoding='utf8')
    (OUT/'RESULTS.txt').write_text('意大利新来源冻结确认已完成。\n主要E2: q90交互15.563762% [7.549041,24.377278]；q95交互19.842045% [9.377260,32.081108]，97.5%配对日历块区间。\n这些不是算法相对Raw的提升。固定反馈复用相对Raw：LightGBM联合损失下降0.862%–1.348%；MLP增加0.740%–2.122%。\nE3全部16个新旧参考差异95%区间跨零。单店、单品类限制保留。\n详细见REPORT.html、analysis/*.csv和freeze_manifest.json。\n',encoding='utf8')
    # Build reviewer package in a fresh task-specific staging folder, preserving relative code layout.
    stage=OUT/'review_package';stage.mkdir(exist_ok=True)
    def cp(src,rel):
        dst=stage/rel;dst.parent.mkdir(parents=True,exist_ok=True)
        if src.suffix=='.parquet':
            frame=pd.read_parquet(src);frame.to_parquet(dst,index=False,compression='zstd',compression_level=19)
            pd.testing.assert_frame_equal(frame,pd.read_parquet(dst))
        else:shutil.copy2(src,dst)
    for p in HERE.glob('*.py'):cp(p,Path('work')/HERE.name/p.name)
    (stage/'requirements-review.txt').write_text('numpy==2.3.5\npandas==3.0.1\npyarrow==23.0.1\n',encoding='utf8')
    (stage/'requirements-models.txt').write_text('-r requirements-review.txt\nlightgbm==4.7.0\nmatplotlib==3.11.2\n# GPU full rerun also requires torch==2.7.1+cu128 from the official PyTorch CUDA12.8 index.\n',encoding='utf8')
    cp(DATA/'hierarchical_sales_data.csv',Path('work')/HERE.name/'data/hierarchical_sales_data.csv')
    patterns=['admission.json','calendar_audit.csv','cohort*.csv','early_panel.npy','environment.json','freeze_manifest.json','protected_access.json','tests_pre_freeze.txt','verification.json','quick_recompute.json','run_complete.json','selection/*/*.json','selection/*/*.csv','selected/daily.parquet','selected/*.csv','analysis/*.csv','analysis/decision.json','candidates/*/daily.parquet','candidates/*/feedback.parquet','candidates/*/costs.csv','e3/*/daily.parquet','e3/*/feedback.parquet','e3/*/pairs.csv','*.log']
    for pattern in patterns:
        for p in OUT.glob(pattern):
            if p.is_file():cp(p,Path('outputs')/OUT.name/p.relative_to(OUT))
    for p in fig.iterdir():cp(p,Path('figures')/p.name)
    for name in ['REPORT.html','RESULTS.txt']:cp(OUT/name,name)
    # Full bank metadata retained as audit records, away from resumable bank paths without weights.
    for p in (OUT/'bank').glob('*/*/complete.json'):cp(p,Path('audit_bank_records')/p.relative_to(OUT/'bank'))
    (stage/'README.txt').write_text('ITALIAN GROCERY EXTERNAL CONFIRMATION — 2026-10-28\n\nOpen REPORT.html for the Chinese results and figures. This archive contains this new experiment only, no manuscript or historical releases.\n\nQuick reviewer reproduction (Python3.12):\n  pip install numpy==2.3.5 pandas==3.0.1 pyarrow lightgbm==4.7.0 matplotlib\n  python work/sr_external_italy_20261028/recompute_review.py\nThis recomputes432 aggregate scores and both5000-replicate co-primary intervals from included daily records.\n\nFull rerun, in an extracted independent copy:\n  Install PyTorch2.7.1 with CUDA12.8 and a compatible GPU (original: RTX5060 Laptop), then:\n  python work/sr_external_italy_20261028/run_all.py\n  python work/sr_external_italy_20261028/verify_run.py\nThe archive retains the selected configurations and immutable freeze. Full rerun regenerates702 models and all candidate arrays; roughly2GiB disk space plus overhead needed. Reported timing is hardware-specific. No confirmation-outcome tuning is permitted.\n\nIncluded: raw provider CSV, provenance, early cohort/statistics, frozen core code, selected and full-grid daily scores, feedback logs, selection history, all result tables, SVG/PDF/PNG figures, audit records.\nExcluded to keep the archive compact: model binaries, per-SKU candidate arrays, duplicate full panel. These remain in the original local workspace and can be regenerated. Audit records are separated from resumable bank directories to avoid pretending excluded model files are present.\n\nThe new reporting, verification and quick-review utilities were added after the frozen run. They do not alter the frozen training, calibration, selection or primary estimators. Their checksums are included in PACKAGE_MANIFEST.json.\n\nFrozen provenance uses UTC. Scores are SKU-origin weighted, seed-score averaged; calendar block intervals condition on fitted/selected paths. One store and one pasta category; no claims of universal calibration benefit.\n',encoding='utf8')
    (stage/'DATA_LICENSE_AND_SOURCE.txt').write_text('Provider data: Mancuso, Paolo; Piccialli, Veronica; Sudoso, Antonio M. (2021). Hierarchical sales data of an Italian grocery store. Mendeley Data V1. DOI10.17632/s8dgbs3rng.1.\nhttps://data.mendeley.com/datasets/s8dgbs3rng/1\nRelated identical CSV: DOI10.17632/njdkntcpc9.1.\nDownloaded via official Download All on2026-10-28.\nProvider record license: Creative Commons Attribution-NonCommercial3.0.\nLicense link: https://creativecommons.org/licenses/by-nc/3.0/\nRaw CSV is unchanged; SHA256 0dfd4a5bf801bf79ddb5fb1f6bc8d023487c36dd6a2a70b312cdfa9fa6568d83.\nDerived analyses identify missing calendar days as NA, retain all118 eligible early-history SKUs, and calculate future H-day totals. Attribution must be preserved and noncommercial terms respected. The different license on a third-party index is not substituted. No blanket license claim is made for project code here.\n',encoding='utf8')
    with (stage/'README.txt').open('a',encoding='utf8') as f:f.write('\nPackage compression: Parquet score/log files are losslessly recompressed with Zstandard level19. Each table is checked exactly against its source after readback; no rows/columns/precision are removed. Binary hashes therefore differ from local Snappy files, while table values and dtypes match. PACKAGE_MANIFEST.json describes the delivered bytes.\nMinimal quick-check installation: pip install -r requirements-review.txt\nFull model dependencies: requirements-models.txt plus the official PyTorch CUDA build described above.\n')
    manifest={str(p.relative_to(stage)).replace('\\','/'):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in stage.rglob('*') if p.is_file() and p.name!='PACKAGE_MANIFEST.json'}
    write(stage/'PACKAGE_MANIFEST.json',dict(created=now(),files=manifest))
    dest=Path('C:/Users/lenovo/Downloads/SR_意大利新来源确认_结果与复现包_20261028.zip')
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in stage.rglob('*'):
            if p.is_file():z.write(p,p.relative_to(stage))
    with zipfile.ZipFile(dest) as z:assert z.testzip() is None
    write(OUT/'delivery.json',dict(created=now(),zip=str(dest),bytes=dest.stat().st_size,sha256=sha(dest),files=len(manifest)+1,report=str(OUT/'REPORT.html')))
    print('DELIVERED',dest,round(dest.stat().st_size/2**20,2),'MiB',len(manifest)+1,'files')
if __name__=='__main__':main()
