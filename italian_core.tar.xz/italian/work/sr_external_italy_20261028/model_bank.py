from common import *
from fitters import lgb_fit,mlp_fit,predict,pinloss,torch_import
import gc,argparse
class Design:
    def __init__(self,H,early=False,tuning=False):
        self.H=H;self.y=np.load(OUT/('early_panel.npy' if early else 'full_panel.npy'));self.n=len(self.y)
        self.meta=pd.read_csv(OUT/'cohort.csv');cut=origin('2015-09-30') if tuning else origin('2015-12-31')
        oo=np.arange(max(56,cut-H-364),cut-H+1)
        self.scale=np.maximum(1,np.nanmean(target(self.y,oo,H),axis=0));self.scale=np.nan_to_num(self.scale,nan=1.)
        h=self.y[:,:cut];freq=(h>0).sum(1)/np.maximum(np.isfinite(h).sum(1),1)
        cats=pd.get_dummies(self.meta.brand,dtype=float).to_numpy()
        self.static=np.column_stack([cats,np.log1p(self.scale),freq]).astype('float32')
    def make(self,origins):
        out=[];denom=self.scale/self.H
        for t in origins:
            assert t>=56;cols=[self.static]
            for lag in [0,1,2,6,13,27,55]:
                v=self.y[:,t-1-lag];cols.extend([np.log1p(np.nan_to_num(v,nan=0)/denom)[:,None],np.isnan(v).astype(float)[:,None]])
            for w in [7,14,28,56]:
                v=self.y[:,t-w:t];n=np.isfinite(v).sum(1);a=np.nan_to_num(v,nan=0);mu=a.sum(1)/np.maximum(n,1);sd=np.sqrt(np.maximum(0,(a*a).sum(1)/np.maximum(n,1)-mu*mu))
                cols.extend([np.log1p(mu/denom)[:,None],np.log1p(sd/denom)[:,None],((v>0).sum(1)/np.maximum(n,1))[:,None],(n/w)[:,None]])
            date=DATES[t-1];phase=date.dayofyear/365.25
            vals=[np.sin(2*np.pi*phase),np.cos(2*np.pi*phase),np.sin(2*np.pi*date.dayofweek/7),np.cos(2*np.pi*date.dayofweek/7)]
            cols.append(np.tile(vals,(self.n,1)));out.append(np.column_stack(cols).astype('float32'))
        return np.stack(out)
    def train(self,cut):
        oo=np.arange(max(56,cut-self.H-364),cut-self.H+1);x=self.make(oo);y=target(self.y,oo,self.H)/self.scale
        ok=np.isfinite(y.ravel());x=x.reshape(-1,x.shape[-1]);y=y.ravel()
        return x[ok],y[ok],dict(cutoff=int(cut),first_origin=int(oo[0]),last_origin=int(oo[-1]),last_target_count=int(oo[-1]+self.H),rows=int(ok.sum()),candidate_rows=len(ok))
def tune():
    assert not (OUT/'protected_access.json').exists()
    for H in [7,14]:
      d=Design(H,early=True,tuning=True);cut=origin('2015-09-30');x,y,audit=d.train(cut)
      oo=np.arange(origin('2015-10-01'),origin('2015-12-17')+1);vx=d.make(oo);vy=target(d.y,oo,H)/d.scale;ok=np.isfinite(vy.ravel());vx=vx.reshape(-1,vx.shape[-1])[ok];vy=vy.ravel()[ok]
      for fam in ['lgbm','mlp']:
        p=OUT/'selection'/f'h{H}_{fam}';p.mkdir(parents=True,exist_ok=True)
        if (p/'selected.json').exists():continue
        rows=[];seconds=0
        if fam=='lgbm':
            m,sec=lgb_fit(x,y,SEEDS[0],512);seconds+=sec
            for rounds in [256,512]:rows.append(dict(rounds=rounds,loss=float(pinloss(vy,ordered(predict(m,vx,fam,rounds))))))
        else:
            for width in [64,128]:
                m,sec,rr,_=mlp_fit(x,y,SEEDS[0],width,20,val=(vx,vy));seconds+=sec
                rows += [dict(width=r['width'],epochs=r['epochs'],loss=r['validation_loss']) for r in rr]
        best=min(rows,key=lambda r:r['loss']);csv(p/'candidates.csv',rows)
        write(p/'selected.json',dict(H=H,family=fam,configuration={k:v for k,v in best.items() if k!='loss'},loss=best['loss'],fit_seconds=seconds,training=audit,validation_first=int(oo[0]),validation_last=int(oo[-1]),last_validation_target=int(oo[-1]+H),selection_seed=SEEDS[0],created=now()))
        print('EARLY_SELECTION',H,fam,best,'seconds',round(seconds,2),flush=True)
def bank(family):
    digest=lock();from intake import unlock
    if not (OUT/'full_panel.npy').exists():unlock()
    for H in [7,14]:
      d=Design(H);cfg=read(OUT/'selection'/f'h{H}_{family}/selected.json')['configuration']
      for seed in SEEDS:
       for cut in cuts():
        p=OUT/'bank'/f'h{H}_{family}_s{seed}'/f'c{cut}';p.mkdir(parents=True,exist_ok=True)
        if (p/'complete.json').exists():
            m=read(p/'complete.json');assert m['freeze_sha256']==digest
            for name,h in m['file_sha256'].items():assert sha(p/name)==h
            continue
        started=time.perf_counter();x,y,audit=d.train(int(cut));assert audit['last_target_count']<=cut
        if family=='lgbm':m,sec=lgb_fit(x,y,seed,cfg['rounds'],p)
        else:m,sec,_,_=mlp_fit(x,y,seed,cfg['width'],cfg['epochs'],p)
        # A U56 predecessor must remain available throughout the NEXT U56 cycle.
        oo=np.arange(cut,min(LAST+1,cut+112));px=d.make(oo);tick=time.perf_counter()
        b=predict(m,px.reshape(-1,px.shape[-1]),family).reshape(len(oo),d.n,2)*d.scale[None,:,None]
        infer=time.perf_counter()-tick;assert np.isfinite(b).all()
        np.savez_compressed(p/'predictions.npz',origins=oo,base=b.astype('float64'))
        write(p/'complete.json',dict(freeze_sha256=digest,H=H,family=family,seed=seed,cutoff=int(cut),configuration=cfg,training=audit,fit_seconds=sec,inference_seconds=infer,total_seconds=time.perf_counter()-started,base_model_count=2 if family=='lgbm' else 1,created=now(),file_sha256={f.name:sha(f) for f in p.iterdir() if f.suffix in ['.npz','.pt','.txt']}))
        print('BANK_COMPLETE',H,family,seed,int(cut),'fit_seconds',round(sec,3),flush=True)
        del m,x,y,px,b;gc.collect()
        if family=='mlp':torch_import().cuda.empty_cache()
    write(OUT/f'bank_{family}_complete.json',dict(created=now(),freeze_sha256=digest))
def assemble(c):
    d=Design(c['H']);oo=np.arange(WARM,LAST+1);b=np.empty((len(oo),d.n,2));v=np.empty(len(oo),int)
    for cut in cuts(c['U']):
        p=OUT/'bank'/f'h{c["H"]}_{c["family"]}_s{c["seed"]}'/f'c{cut}'
        r=load(p/'predictions.npz');ix=np.flatnonzero((oo>=cut)&(oo<cut+c['U']));ri=oo[ix]-cut
        np.testing.assert_array_equal(r['origins'][ri],oo[ix]);b[ix]=r['base'][ri];v[ix]=cut
    return dict(origins=oo,base=b,truth=target(d.y,oo,c['H']),scale=d.scale,groups=d.meta.group.to_numpy(),versions=v)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('mode',choices=['tune','lgbm','mlp']);args=a.parse_args()
    tune() if args.mode=='tune' else bank(args.mode)
