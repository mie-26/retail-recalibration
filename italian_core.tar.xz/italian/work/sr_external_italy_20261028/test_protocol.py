import unittest
from common import *
from kernels import replay_control,weighted_inverse,choose,pair_predictions
from legacy import replay as legacy_replay
from model_bank import Design
from analysis import streams,blockweights
class ProtocolTests(unittest.TestCase):
    def synthetic(self,N=4,T=40):
        rng=np.random.default_rng(4);y=rng.poisson(4,size=(T,N)).astype(float);y[8:10,0]=np.nan
        return dict(truth=y,base=np.tile([2.,3.],(T,N,1)),scale=np.ones(N),groups=np.arange(N)%2,origins=np.arange(100,100+T),versions=np.repeat([100,120],20))
    def test_calendar(self):
        self.assertEqual(LAST-FIRST+1,717);self.assertEqual(len(cuts()),39);self.assertEqual(len(cuts(56)),20)
        self.assertTrue(set(cuts(56)).issubset(set(cuts())))
        self.assertEqual(str(DATES[LAST+14-1].date()),'2018-12-31')
    def test_missing_target(self):
        y=np.array([[1.,2.,np.nan,4.,5.]]);self.assertTrue(np.isnan(target(y,[1],2)[0,0]));self.assertEqual(target(y,[3],2)[0,0],9.)
    def test_maturity_boundary(self):
        z=self.synthetic();q,tr,_=replay_control(z,7,'WQ','series',28)
        np.testing.assert_array_equal(q[:7],ordered(z['base'][:7]));self.assertEqual(tr[7]['latest_maturity'],107)
        for r in tr:self.assertLessEqual(r['latest_maturity'],r['origin'])
    def test_future_perturbation(self):
        z=self.synthetic();zz={k:v.copy() for k,v in z.items()};zz['truth'][20:]=999
        for rule,p in [('WQ',28),('QT',.1)]:
          for sharing in ['series','group','global']:
            a,_,_=replay_control(z,7,rule,sharing,p);b,_,_=replay_control(zz,7,rule,sharing,p);np.testing.assert_array_equal(a[:27],b[:27])
    def test_shared_update_invariant_to_replication(self):
        z=self.synthetic();z['truth']=np.nan_to_num(z['truth'],nan=4)
        zz={k:(np.repeat(v,2,axis=1) if k in ['truth','base'] else np.repeat(v,2) if k in ['scale','groups'] else v.copy()) for k,v in z.items()}
        for rule,p in [('WQ',28),('QT',.1)]:
            a,_,_=replay_control(z,7,rule,'global',p);b,_,_=replay_control(zz,7,rule,'global',p);np.testing.assert_allclose(a,b[:,::2])
    def test_weighted_inverse(self):
        self.assertEqual(weighted_inverse(np.array([0,2,9.]),np.array([.1,.1,.8]),.9),9)
    def test_selection_tie(self):
        self.assertEqual(choose({28:1,56:1,112:1},56),56);self.assertEqual(choose({.03:1,.1:1,.3:1},.1),.1)
    def test_isolation(self):
        z=self.synthetic();q,tr,_=legacy_replay(z['truth'],z['base'],z['scale'],z['groups'],z['origins'],z['versions'],7,'R3_isolate')
        np.testing.assert_array_equal(q[20:27],ordered(z['base'][20:27]));self.assertTrue(all(r['old_origins']==0 for r in tr))
    def test_paired_same_reference(self):
        z=self.synthetic();qq,_=pair_predictions(z['truth'],z['base'],z['base'],z['scale'],z['groups'],z['origins'],7,56);np.testing.assert_array_equal(*qq)
    def test_feature_timing(self):
        d=Design(7,early=True,tuning=True);o=origin('2015-10-01');x=d.make([o]);d.y[:,o:]=1e9;np.testing.assert_array_equal(x,d.make([o]))
    def test_training_boundary(self):
        for H in [7,14]:
            d=Design(H,early=True,tuning=True);_,_,a=d.train(origin('2015-09-30'));self.assertEqual(a['last_target_count'],a['cutoff'])
    def test_calendar_resampling(self):
        w=blockweights(30,7,20);np.testing.assert_array_equal(w.sum(1),np.full(20,30));self.assertEqual(w.shape,(20,30))
    def test_statistical_denominator(self):
        # Same two actual dates receive one and ten valid pairs; zero days stay on calendar.
        rows=[dict(method='Raw',origin=o,scaled_pinball=v,n=n) for s in SEEDS for o,v,n in [(FIRST,1.,1),(FIRST+1,2.,10)]]
        nums,n=streams(pd.DataFrame(rows),['Raw']);self.assertEqual(len(n),717);self.assertAlmostEqual(nums['Raw'].sum()/n.sum(),21/11)
    def test_early_access(self):
        a=read(OUT/'admission.json');self.assertTrue(a['identical_csv_versions']);self.assertEqual(a['numerical_values_read_through'],'2015-12-31')
        y=np.load(OUT/'early_panel.npy');self.assertTrue(np.isnan(y[:,origin('2015-12-31'):]).all())
if __name__=='__main__':unittest.main(verbosity=2)
